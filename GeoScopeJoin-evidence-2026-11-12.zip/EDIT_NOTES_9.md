# Nine requested revisions

## 4. Window manifest anchor

```latex
The archived Round~2 manifest \texttt{bench\_freeze.json} records the window hashes and a self-reported freeze time of 2026-10-29 08:11:03 UTC; the raw route verifies decoded windows against them. The local manifest is included in the revision evidence package.
```

## 1. Shenzhen postselection

```latex
The query uses four frozen regions (whole, hole, multipart, and an expanded envelope), which produce many \nocover{} rows. The envelope is the axis-aligned Mollweide min--max box of the four projected corners of the WGS84 movement-search box $[113.55,114.35]^\circ$E $\times[22.2,22.85]^\circ$N; the point snapshots were extracted from this search box. Shenzhen sessions on these snapshots are therefore postselected with respect to the movement search; the synthetic controlled matrix is separate from this event selection.
```

## 3. Historical environment and freeze provenance

```latex
The historical G0 record reports Windows 10, a 12-logical-CPU Intel64 processor, 17,007,095,808 bytes of memory, Python 3.13.14, NumPy 2.2.6, Shapely 2.1.2, Rasterio 1.4.3 and pyproj 3.7.2. Session reports lack immutable per-run host identifiers, so G0 cannot independently establish the host of every timing. Full performance re-execution on the current host is \texttt{NOT\_RUN}; the archived protocols, source digests and session results support regeneration. The E1 report records a freeze digest beginning \texttt{6075f6c6}, whereas the archived freeze manifest begins \texttt{b116834c}; the E1-matching manifest has not been located.
```

## 7. Protocol and threshold anchor

```latex
The protocol-specified practical threshold calls an improvement stable only if the interval's upper bound is below 0.95. The archived \texttt{round5\_evaluation/protocols/R5\_PROTOCOL.md} states a freeze date of 2026-11-10 (SHA-256 prefix \texttt{7b79f944e3cc1307}); this local date is not an independently timestamped preregistration.
```

## 6. Actual retry rule

```latex
All eight cells contain 90 passing sessions. The implementation permits at most one retry of an individual session after \texttt{TIMING\_INVALID}, \texttt{CRASH}, or \texttt{RESOURCE\_LIMIT}, but not after correctness failures; both attempts are retained. One full-evaluation baseline session was retried after \texttt{TIMING\_INVALID} and passed. The protocol describes rerunning the whole pair, whereas the implementation retried only the failed session; the Lazy/Eager pair was unaffected by this baseline retry.
```

## 8. Identity boundary

```latex
and under W3, where every state is queried, the ratios are 0.975--1.015, consistent with the identity's boundary prediction. Shenzhen also includes insertions and deletions, which are outside the identity's fixed-point premise.
```

## 9. Query percentile conventions

```latex
The six queries per budget belong to one session. For sorted latencies $x_0,\ldots,x_5$, p95 is $x_{\lfloor0.95(6-1)\rfloor}=x_4$ (the fifth observation). The reported p50 uses $x_2$ for the tile cache but $x_3$ for the Lazy reference; their ratio therefore compares different median conventions.
```

## 2. Amortization sample sizes and intervals

```latex
Reusing a registered snapshot reduces per-request cost by 12--31$\times$ at $H=100$ in the original analysis (Table~\ref{tab:e1amort}; $n=7$ sessions per cell versus $n=30$ at $H=1$). The postprocessor excluded blocks 0--2 as smoke runs at every $H$, although the $H=10$ and $H=100$ loops each recorded ten passing sessions without a separate smoke designation. Including all ten gives $H=100$ ratios of 12.34--30.22$\times$. Intervals are exploratory post-hoc independent session bootstraps (10\,000 draws, seed 20261112): $H=1$ and $H>1$ were measured in separate passes. The cost is the sum of separate registration and online medians, divided by $H$. These results measure preparation amortization; the controlled paired experiment in Table~\ref{tab:e2timing} measures deferred maintenance.
```

## 1b. Movement region selection

```latex
two postselected regions constructed to separate the old and new positions:
```

## 5. NoData fixture versus real data

```latex
The controlled matrix isolates the effects of overlap and query spacing. The evaluated real windows contain no NoData transitions. In a post-hoc synthetic fixture executed on the current host, valid-to-NoData and NoData-to-valid changes were exercised across four engines and three states, yielding 12 of 12 row-set checks against the reference. The event-guard tests cover ordered events and rejection of invalid transitions.
```
