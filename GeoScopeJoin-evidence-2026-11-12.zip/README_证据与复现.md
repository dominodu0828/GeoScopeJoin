# 九项证据修订：材料说明

- `main.pdf` 是本次新生成的审阅稿；`main.tex`、`body.tex`、`tables/`、`figure_single/` 与参考文献文件构成可在本目录编译的 LaTeX 源稿。
- `EDIT_NOTES_9.md` 列出九项修改所用的英文 LaTeX 文案；摘要中另外明确标注 H=100 每格 n=7、H=1 每格 n=30。
- `amortization_audit.json` 和 `audit_amortization.py` 记录 H=10/H=100 原有会话的复核、n=7 区间和全部 10 次合格会话的敏感性分析。此分析读取同级项目目录中的历史原始会话，未重跑性能试验；独立重采样会话，种子 20261112，10000 次。区间不处理不同执行批次或主机的偏差。
- `verify_r5_nodata_fixture.py` 和 `nodata_r5_current_host.json` 记录本轮在当前环境新增执行的合成 NoData 双向转换夹具；依赖同级项目目录中的 Round 5 代码和 Python 环境。该夹具不是历史真实性能或真实 NoData 事件。
- `evidence/bench_freeze.json` 的自记录时间为 2026-10-29 08:11:03 UTC，SHA-256 为 `551fd5a3223e9330b7b1e9b89253ba36ff2db9c8a006515bbd2c1d36cbf0a918`；此时间没有独立时间戳证明。
- `evidence/R5_PROTOCOL.md` 的自述冻结日期为 2026-11-10，SHA-256 为 `7b79f944e3cc1307364644cc145bbb1804699735c4e32294b67a6deb34260efe`；文件自述时间不是独立预注册证明。
- 历史 E1 报告的 freeze SHA-256 为 `6075f6c64be809255e8d7157886b955c187889ad0f1cc3b467a0da4a4db5b282`，目前归档的 `freeze_g0.json` 哈希为 `b116834cc5de86679c522e64605854790a725e0601613b48009c044aca19d0c5`；没有找到与前者匹配的清单。G0 没有为每次计时提供不可变主机 ID，不能据此确认全部计时使用相同主机。当前主机完整性能矩阵复测为 NOT_RUN。
- 本修订包配合仓库的 [v1.0.0 历史实验数据](https://github.com/dominodu0828/GeoScopeJoin/releases/tag/v1.0.0) 使用。按该版本说明还原 `GeoScopeJoin-restored` 后，将本包解压至其子目录 `paper_evidence_revision_20261112`。在已安装项目依赖的 Python 环境中，从还原根目录执行 `python paper_evidence_revision_20261112/audit_amortization.py` 和 `python paper_evidence_revision_20261112/verify_r5_nodata_fixture.py`，可分别重算摊销结果和复查双向 NoData 转换。
