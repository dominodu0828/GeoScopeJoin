from pathlib import Path
import collections, json, random, statistics

root=Path(__file__).resolve().parents[1]
run=root/'round5_evaluation/runs/20261110T144228Z_b6248e873491_e1/sessions'
records=collections.defaultdict(list)
for f in sorted(run.glob('*.json')):
    d=json.loads(f.read_text(encoding='utf-8')); c=d.get('config',{})
    if c.get('route')!='registered_service' or c.get('schedule')!='W2_final_only': continue
    if c.get('engine') not in ('B3-Eager','B3-Lazy') or c.get('H',1) not in (1,10,100):continue
    key=(c['dataset'],c['engine'],c.get('H',1))
    t=d.get('timers',{}); reg=(t.get('register') or {}).get('total_s'); online=t.get('online_total_s')
    records[key].append({'block':c['block'],'status':d.get('status'),'register':reg,'online':online,'file':f.name})

def metric(rows,h):
    return (statistics.median(x['register'] for x in rows)+statistics.median(x['online'] for x in rows))/h
def boot(base,target,h,seed=20261112,reps=10000):
    rnd=random.Random(seed);vals=[]
    for _ in range(reps):
        a=[rnd.choice(base) for _ in base];b=[rnd.choice(target) for _ in target]
        vals.append(metric(a,1)/metric(b,h))
    vals.sort();return [vals[249],vals[9749]]
report={'method':'Unpaired percentile bootstrap, independently resample whole sessions in H1 and H target; each statistic uses sum of separate medians of registration and online, divided by H. H1 and target runs were in separate passes. Exploratory, post hoc; seed 20261112, 10000 draws.','groups':{}}
for dataset in sorted({k[0] for k in records}):
  for engine in ('B3-Eager','B3-Lazy'):
    base=[r for r in records[dataset,engine,1] if r['status']=='PASS' and r['block']>=3]
    entry={'h1_n':len(base),'h1_median_s':metric(base,1)}
    for h in (10,100):
      allrows=records[dataset,engine,h]
      eligible=[r for r in allrows if r['status']=='PASS' and r['register'] is not None and r['online'] is not None]
      selected=[r for r in eligible if r['block']>=3]
      entry[str(h)]={'all_statuses':dict(collections.Counter(r['status'] for r in allrows)),'all_blocks':sorted(r['block'] for r in allrows),'excluded_0_2':[{'block':r['block'],'status':r['status']} for r in allrows if r['block']<3], 'n_reported':len(selected),'n_all_pass':len(eligible),'reported_per_request':metric(selected,h),'reported_speedup':metric(base,1)/metric(selected,h),'reported_speedup_ci95':boot(base,selected,h),'all_pass_per_request':metric(eligible,h),'all_pass_speedup':metric(base,1)/metric(eligible,h),'all_pass_speedup_ci95':boot(base,eligible,h)}
    report['groups'][dataset+'|'+engine]=entry
(Path(__file__).parent/'amortization_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
