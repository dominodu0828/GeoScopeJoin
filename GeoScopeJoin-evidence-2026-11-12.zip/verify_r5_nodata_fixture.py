from pathlib import Path
import json,sys
root=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(root/'round5_evaluation/code'),str(root/'.deps')]
import numpy as np
from shapely.geometry import box
import r5_common as C, engines_r5 as E, reference_native as R

grid=C.grid_of(0.,0.,2,dx=100.,dy=100.)
points={'a':(0,0,50.,50.,1),'b':(0,0,150.,50.,1)}
regions={'all':box(0,0,200,200)}
arrays=[np.array([[1.,1.],[5.,-200.]]), np.array([[1.,1.],[-200.,7.]]),np.array([[1.,1.],[8.,-200.]])]
cells=[C.encode_array(a,-200.,'units') for a in arrays]
classes=[('BFull-Fast',E.BFullFast,{}),('B3-Eager',E.B3Eager,{}),('B3-Lazy',E.B3Lazy,{}),('B2-byte',E.B2Byte,{'budget_bytes':10000000})]
results=[]
for name,cls,kwargs in classes:
    e=cls(points,cells[0],grid,regions,**kwargs)
    for i in range(3):
        if i: e.update(points,points,cells[i-1],cells[i],[(0,0),(1,0)],[])
        rv='r%d'%i;actual=e.query(rv,'p','rh'+str(i),'ph')
        expected,lookup=R.expected_rows(arrays[i],-200.,grid,points,regions,'units',rv,'p','rh'+str(i),'ph')
        ok,diff=R.verify(actual,expected)
        expected_statuses=[['OBSERVED','NODATA'],['NODATA','OBSERVED'],['OBSERVED','NODATA']][i]
        assert [lookup['a'][1],lookup['b'][1]]==expected_statuses
        if not ok: raise AssertionError((name,i,diff))
        results.append({'engine':name,'state':i,'ok':ok,'statuses':expected_statuses})
    e.close()
out={'description':'Post-hoc synthetic two-cell valid/NoData bidirectional fixture; same query reference as R5, not a real transition or historical R5 result.','engine_sequences':4,'states_per_sequence':3,'row_set_checks':len(results),'all_match':all(x['ok'] for x in results),'results':results}
(Path(__file__).parent/'nodata_r5_current_host.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='results'},indent=2))
