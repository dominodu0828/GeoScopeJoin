# 复现包说明（Round 5）

包文件：`round5_evaluation/reports/r5_reproduction_packet.zip`（41 个文件，约 99 KB）。
**状态：已打包，未公开发布，因此目前没有 URL。** 本方案禁止在作者授权前发布外部材料。

## 一、包里有什么

| 目录 | 内容 |
|---|---|
| `code/` | 全部实验代码（会话执行器、引擎、原生判据、数据集、G0 门、E1–E5 运行器） |
| `protocols/` | 执行前冻结的协议与参数矩阵（`R5_PROTOCOL.md`、`matrix.json`） |
| `manifests/` | 来源登记（窗口哈希、点文件哈希、编码）、原生判据摘要、闭包冻结 |
| `reports/` | 六个实验的原始 JSON、`R5_RESULTS.md`、`CLAIM_LEDGER_R5.csv`、`STATUS.csv`、LaTeX 表 |
| `tools/` | 汇总器、摊销重算、LaTeX 表生成 |
| `PACKET_INVENTORY.json` | 包内每个文件的 SHA-256 |

## 二、包里没有（以及原因）

- **原始栅格与点快照**（约 250 MB ZIP）。GHSL 为 CC BY 4.0，OSM 为 ODbL，可以随包分发，但体积大且需保留上游许可文本；放不进 100 KB 的包。
- **注册快照与运行目录**（`runs/`，含每会话结果与派生 NPY，约 1.4 GB）。
- **R2022A 的 R7_C29 tile**：上游已下架（`---OBSOLETE_RELEASE---` 标记），只有本地归档副本，无法提供公开下载地址。

复现所需输入的获取方式与哈希全部写在 `manifests/dataset_*.json`：`zip_sha256`、`member_sha256`、`window_sha256_npy`、点文件 `sha256`、`url`。只要拿到同一批字节，raw 路线会逐字节校验（含 `npy` 窗口哈希），不匹配即 `SOURCE_FAIL`。

## 三、复现命令（把包解压为 `round5_evaluation/`，Python 3.13 + numpy/shapely/rasterio/pyproj/psutil）

```bash
python -I code/run_g0.py                     # ~25 s，重建 manifests 与 freeze
python -I code/run_e2.py --skip-timing       # 机制计数，~11 min
python -I code/run_e2.py --skip-counts --blocks 30   # 时延端点，~19 min
python -I code/run_e1.py --amortization      # 872 会话，~65 min
python -I code/run_e4.py                     # ~2 min
python -I code/run_e3.py                     # ~2 min
python -I code/run_e5.py                     # ~10 s
python -I tools/recompute_amort.py
python -I tools/make_reports.py && python -I tools/make_latex_tables.py
```

## 四、复现时应看到的关键数字

- G0：闭包 165 文件、0 问题；7/7 负对照被拒；8/8 数值类通过。
- E2：计数残差 0；时延中位 1.023 / 0.990 / 0.836。
- E1：8 个配置各 90/90 PASS；无配置 CI 上界 <0.95；摊销 12.4–30.7×。
- E4：三档预算 0 违反；p50 0.539 / 0.393 / 0.381 s。
- E5：16/16 行级一致；事件门 6 类用例。

计时类数字依赖机器，允许有量级内差异；**正确性门与计数恒等式必须逐位一致**（计数不依赖计时）。

## 五、发布选项（需要你授权）

1. **GitHub / Zenodo**：把本包 + 许可说明上传；数据单独放一个带 DOI 的归档（需先确认 GHSL/OSM 再分发条款）。
2. **仅代码与报告**：上传本包，数据只给获取脚本与哈希，审稿人按 §三 自行下载。这是最常见的做法，也最省事。
3. **不发布**：稿中只能写 "local artifact available from the authors"，不能写 URL。

告诉我选哪个、放到哪个账号，我再执行；在此之前稿子里不会出现任何虚构链接。
