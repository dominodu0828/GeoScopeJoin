"""Round 5 datasets: real release pair, real cross-epoch sequence, controlled matrix.

Everything is read as data. No round2/round3/round4 module is imported, so the
freeze closure of the execution path stays inside round5 plus registered inputs.

Datasets
--------
shenzhen_same_epoch_release_pair
    GHS-POP E2020 R2022A -> R2023A on tile R7_C29, frozen 256x256 window at
    (10857900, 2744600). Three point snapshots (2023/2024/2025 files). Two events:
    a point-only event, then a joint point+raster event.
sao_paulo_cross_epoch_published_grids
    GHS-POP R2023A E2015 -> E2020 -> E2025 -> E2030 on tile R12_C14, window centred
    on the coordinate-wise median of the frozen point snapshot. Cross-epoch, not a
    release revision; 2025/2030 are published projections.
synthetic E2
    Controlled 256x256 grid, 8192 points, 16 events, shared core + exclusive tail.
"""
import hashlib
import json
import math
import pathlib
import statistics
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

import numpy as np

import r5_common as C
import reference_native as REF

WIN = 256
NODATA = -200.0
SRC = HERE / 'inputs'  # Publication: bundled original source bytes


def local_input(path):
    """Bring an external input under the project root so the freeze covers it."""
    import shutil
    p = pathlib.Path(path)
    try:
        p.relative_to(PROJ)
        return p
    except ValueError:
        d = HERE / 'inputs'
        d.mkdir(parents=True, exist_ok=True)
        q = d / p.name
        if not q.exists() or C.sha256_file(q) != C.sha256_file(p):
            shutil.copy2(p, q)
        return q

R2_INPUTS = PROJ / 'round2' / 'raster_revision' / 'inputs'
R3 = PROJ / 'round3' / 'imd_locality'
R4 = PROJ / 'round4_replication'

SHENZHEN = {
    'name': 'shenzhen_same_epoch_release_pair',
    'tile': 'R7_C29',
    'zips': [R2_INPUTS / 'GHS_POP_E2020_R2022A_R7_C29.zip', PROJ / 'inputs' / 'R7_C29.zip'],
    'releases': ['R2022A V1-0', 'R2023A V1-0'],
    'npy': [R2_INPUTS / 'r2022_window.npy', R2_INPUTS / 'r2023_window.npy'],
    'window': {'row0': 2298, 'col0': 8989, 'size': WIN, 'x0': 10857900.0, 'y0': 2744600.0},
    'point_files': [R3 / 'inputs' / 'holdout_osm_2023-10-14.json',
                    R3 / 'experiments' / 'run_20261106_004925_2959818' / 'inputs' / 'expanded_nodes_2024-10-14.json',
                    R3 / 'experiments' / 'run_20261106_004925_2959818' / 'inputs' / 'expanded_nodes_2025-10-14.json'],
    'states': [(0, 0), (0, 1), (1, 2)],   # (raster version index, point file index)
}

SAO_PAULO = {
    'name': 'sao_paulo_cross_epoch_published_grids',
    'tile': 'R12_C14',
    'epochs': ['E2015', 'E2020', 'E2025', 'E2030'],
    'zips': [local_input(R4 / 'inputs' / 'GHS_POP_E2015_GLOBE_R2023A_54009_100_V1_0_R12_C14.zip'),
             local_input(SRC / 'R12_C14.zip'),   # E2020 product, moved under the project root
             local_input(R4 / 'inputs' / 'GHS_POP_E2025_GLOBE_R2023A_54009_100_V1_0_R12_C14.zip'),
             local_input(R4 / 'inputs' / 'GHS_POP_E2030_GLOBE_R2023A_54009_100_V1_0_R12_C14.zip')],
    'point_file': local_input(R4 / 'inputs' / 'osm' / 'osm_sao_paulo_hospital_clinic_window.json'),
}


# --------------------------------------------------------------------- loaders
def load_osm(path):
    """OSM JSON -> {pid: (lon, lat, x, y, version)} with ESRI:54009 projection."""
    from pyproj import Transformer
    T = Transformer.from_crs('EPSG:4326', 'ESRI:54009', always_xy=True)
    raw = pathlib.Path(path).read_bytes()
    data = json.loads(raw)
    points, missing = {}, []
    for e in data.get('elements', []):
        xy = e if e['type'] == 'node' else e.get('center', {})
        if 'lon' not in xy or 'lat' not in xy:
            missing.append('%s/%s' % (e['type'], e['id']))
            continue
        pid = '%s/%s' % (e['type'], e['id'])
        x, y = T.transform(xy['lon'], xy['lat'])
        points[pid] = (xy['lon'], xy['lat'], x, y, e.get('version'))
    info = {
        'path': str(pathlib.Path(path).relative_to(PROJ).as_posix()),
        'sha256': C.sha256_bytes(raw),
        'bytes': len(raw),
        'elements': len(points),
        'skipped_without_coordinates': missing,
        # Documented query metadata. It is NOT the vintage of the map state, so it
        # is recorded separately and never substituted for a snapshot time.
        'overpass_base': (data.get('osm3s') or {}).get('timestamp_osm_base'),
        'max_element_timestamp': max([e.get('timestamp') for e in data.get('elements', [])
                                      if e.get('timestamp')] or [None]),
    }
    return points, info


def zip_member(zip_path):
    import zipfile
    with zipfile.ZipFile(zip_path) as z:
        return next(n for n in z.namelist() if n.lower().endswith('.tif'))


def open_zip_tif(zip_path):
    import rasterio
    member = zip_member(zip_path)
    return rasterio.open('/vsizip/' + pathlib.Path(zip_path).as_posix() + '/' + member)


def decode_zip_window(zip_path, row0, col0, win=WIN):
    """Decode the native window from the source ZIP (raw service path)."""
    with open_zip_tif(zip_path) as src:
        arr = src.read(1, window=((row0, row0 + win), (col0, col0 + win)))
        meta = {'crs': str(src.crs), 'transform': list(src.transform)[:6],
                'width': src.width, 'height': src.height, 'dtype': src.dtypes[0],
                'nodata': float(src.nodata) if src.nodata is not None else None,
                'scale': float(src.scales[0]) if src.scales else 1.0,
                'offset': float(src.offsets[0]) if src.offsets else 0.0,
                'member': zip_member(zip_path)}
    return arr.astype('float64'), meta


def describe_source(zip_path, row0, col0, win=WIN):
    """Registered source record for one ZIP plus window; hashes only real bytes."""
    import zipfile
    zp = pathlib.Path(zip_path)
    member = zip_member(zp)
    with zipfile.ZipFile(zp) as z:
        mh = hashlib.sha256(z.read(member)).hexdigest()
    arr, meta = decode_zip_window(zp, row0, col0, win)
    rec = {
        'zip_path': str(zp.relative_to(PROJ).as_posix()),
        'zip_sha256': C.sha256_file(zp),
        'zip_bytes': zp.stat().st_size,
        'member': member, 'member_sha256': mh,
        'crs': meta['crs'], 'transform': meta['transform'],
        'width': meta['width'], 'height': meta['height'],
        'dtype': meta['dtype'], 'nodata': meta['nodata'],
        'scale': meta['scale'], 'offset': meta['offset'],
        'window': {'row0': row0, 'col0': col0, 'size': win,
                   'x0': float(col0 * 100.0 + meta['transform'][2]),
                   'y0': float(meta['transform'][5] - (row0 + win) * 100.0)},
        'window_sha256_npy': C.sha256_npy(arr),
        'values_nonfinite': int(np.count_nonzero(~np.isfinite(arr))),
        'values_nodata': int(np.count_nonzero(arr == NODATA)),
    }
    return rec, arr


# ------------------------------------------------------------------- Shenzhen
def build_shenzhen():
    spec = SHENZHEN
    win = spec['window']
    sources, arrs = [], []
    for zp in spec['zips']:
        rec, arr = describe_source(zp, win['row0'], win['col0'])
        sources.append(rec)
        arrs.append(arr)
    # The registered NPY windows were hashed in round2, before this round existed,
    # so the raw decode has an independent reference it must reproduce.
    for i, (rec, npyp) in enumerate(zip(sources, spec['npy'])):
        npy_arr = np.load(npyp)
        rec['registered_npy'] = str(npyp.relative_to(PROJ).as_posix())
        rec['registered_npy_sha256'] = C.sha256_file(npyp)
        rec['npy_matches_decode'] = bool(np.array_equal(npy_arr, arrs[i]))

    grid = C.grid_of(win['x0'], win['y0'], WIN)
    regions = C.regions_proportional(win['x0'], win['y0'], WIN)
    # The audited historical query also used an expanded bounding envelope, which is
    # what produces the many NO_COVERAGE rows of this sparse window. It is part of the
    # frozen query, so it is reproduced here rather than dropped.
    regions['expanded'] = expanded_envelope()
    point_sets, point_infos = [], []
    for pf in spec['point_files']:
        pts, info = load_osm(pf)
        point_sets.append(pts)
        point_infos.append(info)

    encoding = 'units' if all(C.encodable_units(arr.ravel()) for arr in arrs) else 'hex'
    cells = [C.encode_array(arr, NODATA, encoding) for arr in arrs]

    states = []
    for rv_i, pv_i in spec['states']:
        # Keep every point: points outside the window are NO_COVERAGE rows, which is
        # the contract case this sparse historical window is here to exercise.
        pts = dict(point_sets[pv_i])
        states.append({'points': pts,
                       'cells': cells[rv_i],
                       'arr': arrs[rv_i],
                       'rv': spec['releases'][rv_i],
                       'rh': sources[rv_i]['zip_sha256'],
                       'pv': 'snapshot:' + point_infos[pv_i]['sha256'],
                       'ph': point_infos[pv_i]['sha256'],
                       'raster_index': rv_i, 'point_index': pv_i})
    events = []
    for a, b in zip(states, states[1:]):
        changed = sorted(k for k in a['cells'].keys() | b['cells'].keys()
                         if a['cells'].get(k) != b['cells'].get(k))
        pids = sorted(set(a['points']) ^ set(b['points']) |
                      {p for p in set(a['points']) & set(b['points'])
                       if a['points'][p][2:4] != b['points'][p][2:4]})
        events.append({'changed_cells': changed, 'changed_pids': pids,
                       'cells': len(changed), 'points': len(pids),
                       'synthetic': False})
    meta = {
        'dataset': spec['name'], 'tile': spec['tile'], 'window': win,
        'point_filter': 'all',
        'sources': sources, 'point_sources': point_infos,
        'value_encoding': encoding,
        'grid': grid, 'regions_wkb_sha256': C.regions_wkb_sha(regions),
        'regions_wkb': {gid: g.wkb.hex() for gid, g in regions.items()},
        'states': [{'rv': s['rv'], 'rh': s['rh'], 'pv': s['pv'], 'ph': s['ph'],
                    'points': len(s['points']), 'raster_index': s['raster_index']}
                   for s in states],
        'events': [{'cells': e['cells'], 'points': e['points'],
                    'synthetic': e['synthetic']} for e in events],
    }
    return {'spec': spec, 'states': states, 'events': events, 'grid': grid,
            'regions': regions, 'meta': meta, 'encoding': encoding}


def expanded_envelope(lo=(113.55, 114.35), la=(22.2, 22.85)):
    """Frozen expanded envelope of the audited query (lon/lat box -> Mollweide)."""
    from pyproj import Transformer
    from shapely.geometry import box
    T = Transformer.from_crs('EPSG:4326', 'ESRI:54009', always_xy=True)
    xs, ys = [], []
    for lon in lo:
        for lat in la:
            x, y = T.transform(lon, lat)
            xs.append(x)
            ys.append(y)
    return box(min(xs), min(ys), max(xs), max(ys))


def _inside(p, grid):
    col, row, ok = REF._row_col(p[2], p[3], grid)
    return ok


# ----------------------------------------------------------------- Sao Paulo
def build_sao_paulo():
    spec = SAO_PAULO
    pts_all, pinfo = load_osm(spec['point_file'])
    # window rule frozen in round4: median of the point snapshot, clamped in tile.
    base = open_zip_tif(spec['zips'][1])
    xs = [p[2] for p in pts_all.values()]
    ys = [p[3] for p in pts_all.values()]
    cx, cy = statistics.median(xs), statistics.median(ys)
    t = base.transform
    col0 = max(0, min(base.width - WIN, int(round((cx - t.c) / 100.0)) - WIN // 2))
    row0 = max(0, min(base.height - WIN, int(round((t.f - cy) / 100.0)) - WIN // 2))
    base.close()

    sources, arrs = [], []
    for zp in spec['zips']:
        rec, arr = describe_source(zp, row0, col0)
        sources.append(rec)
        arrs.append(arr)
    x0 = sources[0]['window']['x0']
    y0 = sources[0]['window']['y0']
    grid = C.grid_of(x0, y0, WIN)
    regions = C.regions_proportional(x0, y0, WIN)
    pts = {pid: p for pid, p in pts_all.items() if _inside(p, grid)}
    encoding = 'units' if all(C.encodable_units(a.ravel()) for a in arrs) else 'hex'
    cells = [C.encode_array(a, NODATA, encoding) for a in arrs]
    states = [{'points': pts, 'cells': cells[i], 'arr': arrs[i],
               'rv': 'GHSL-%s-R2023A-V1-0' % ep, 'rh': sources[i]['zip_sha256'],
               'pv': 'snapshot:' + pinfo['sha256'], 'ph': pinfo['sha256'],
               'raster_index': i, 'point_index': 0}
              for i, ep in enumerate(spec['epochs'])]
    events = []
    for a, b in zip(states, states[1:]):
        changed = sorted(k for k in a['cells'] if a['cells'].get(k) != b['cells'].get(k))
        events.append({'changed_cells': changed, 'changed_pids': [],
                       'cells': len(changed), 'points': 0, 'synthetic': False})
    meta = {
        'dataset': spec['name'], 'tile': spec['tile'],
        'point_filter': 'inside_window',
        'window': {'row0': row0, 'col0': col0, 'size': WIN, 'x0': x0, 'y0': y0},
        'sources': sources, 'point_sources': [pinfo], 'value_encoding': encoding,
        'grid': grid, 'regions_wkb_sha256': C.regions_wkb_sha(regions),
        'regions_wkb': {gid: g.wkb.hex() for gid, g in regions.items()},
        'states': [{'rv': s['rv'], 'rh': s['rh'], 'pv': s['pv'], 'ph': s['ph'],
                    'points': len(s['points']), 'raster_index': i}
                   for i, s in enumerate(states)],
        'events': [{'cells': e['cells'], 'points': 0, 'synthetic': False} for e in events],
        'epoch_note': 'cross-epoch sequence inside R2023A; 2025/2030 are published projections, not observed history',
    }
    return {'spec': spec, 'states': states, 'events': events, 'grid': grid,
            'regions': regions, 'meta': meta, 'encoding': encoding}


# ---------------------------------------------------------------- synthetic E2
def build_e2(core_h, gap, seed, points_per_cell=1):
    """Controlled fixed-point-set workload with a shared core and disjoint tails.

    `core_h` counts CELLS that every event touches (the shared core); the rest of each
    event's 256 cells are event-exclusive. points_per_cell=1 gives one object per
    changed cell; points_per_cell>1 separates object count from cell count.
    """
    n_points, events, m = 8192, 16, 256
    n_cells = n_points // points_per_cell
    if (events - 1) * (m - core_h) + m > n_cells:
        raise ValueError('layout needs more cells than available')
    grid = C.grid_of(0.0, 0.0, WIN)
    regions = C.regions_proportional(0.0, 0.0, WIN)
    rng = np.random.default_rng(seed)

    flat = rng.choice(WIN * WIN, size=n_cells, replace=False)
    cell_list = [(int(f % WIN), int(f // WIN)) for f in flat]
    points, cell_of_point = {}, []
    for ci, (col, row) in enumerate(cell_list):
        for k in range(points_per_cell):
            i = ci * points_per_cell + k
            jx = 0.2 + 0.6 * ((i * 2654435761) % 1000) / 1000.0
            jy = 0.2 + 0.6 * ((i * 40503) % 1000) / 1000.0
            points['s%05d' % i] = (0.0, 0.0, col * 100.0 + jx * 100.0,
                                   row * 100.0 + jy * 100.0, 1)
            cell_of_point.append(ci)
    pids_of_cell = [[] for _ in range(n_cells)]
    for i, ci in enumerate(cell_of_point):
        pids_of_cell[ci].append('s%05d' % i)

    core_cells = list(range(core_h))
    tail_cells, cursor = [], core_h
    for _ in range(events):
        tail_cells.append(list(range(cursor, cursor + (m - core_h))))
        cursor += (m - core_h)

    cells = {}
    for (col, row) in cell_list:
        cells[(col, row)] = ('%d:%d' % (WIN - 1 - row, col), C.encode_units(1.0))
    cells0 = dict(cells)
    evs = []
    for e in range(events):
        idx = core_cells + tail_cells[e]
        value = 2 if e % 2 == 0 else 1
        keys = []
        for ci in idx:
            col, row = cell_list[ci]
            cells[(col, row)] = ('%d:%d' % (WIN - 1 - row, col), C.encode_units(float(value)))
            keys.append((col, row))
        evs.append({'changed_cells': sorted(keys), 'changed_pids': [],
                    'cells': len(keys), 'points': 0, 'synthetic': True,
                    'core_h': core_h, 'event': e, 'cell_indices': idx,
                    'value': C.encode_units(float(value))})

    A_pid = [{pid for ci in e['cell_indices'] for pid in pids_of_cell[ci]} for e in evs]
    groups = [set().union(*A_pid[j:j + gap]) for j in range(0, events, gap)]
    predicted = {'n': n_points, 'points_per_cell': points_per_cell,
                 'sum_affected': sum(len(a) for a in A_pid),
                 'union_per_query': [len(g) for g in groups],
                 'C_E': n_points + sum(len(a) for a in A_pid),
                 'C_L': n_points + sum(len(g) for g in groups)}
    for e in evs:
        e.pop('cell_indices')
    return {'grid': grid, 'regions': regions, 'points': points, 'cells0': cells0,
            'events': evs, 'predicted': predicted,
            'layout': {'core_h': core_h, 'gap': gap, 'seed': seed,
                       'events': events, 'affected_per_event_cells': m,
                       'points_per_cell': points_per_cell, 'points': n_points,
                       'data_class': 'synthetic-controlled'}}


# --------------------------------------------------------------- registration
def register_snapshot(arr, run_dir, name):
    """Write an immutable snapshot and return its content identity."""
    import numpy as np
    d = pathlib.Path(run_dir) / 'registered'
    d.mkdir(parents=True, exist_ok=True)
    p = d / (name + '.npy')
    np.save(p, arr, allow_pickle=False)
    return {'path': str(p), 'sha256': C.sha256_file(p), 'bytes': p.stat().st_size}
