"""Discovery pass: what does a representative session actually open and import?

Runs a small synthetic session in this subprocess with an audit hook on `open`, then
prints, as JSON on the last line:
  - project modules in sys.modules (by file),
  - project files opened at runtime,
  - third-party modules and versions.
"""
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

opened = set()


def hook(event, args):
    if event == 'open':
        try:
            p = args[0]
            if isinstance(p, (str, bytes, pathlib.Path)):
                q = pathlib.Path(p)
                if q.is_absolute() and str(q.resolve()).startswith(str(PROJ)):
                    opened.add(str(q.resolve()))
        except Exception:
            pass


def main():
    import r5_common as C
    import datasets_r5 as D
    import engines_r5 as E
    import session_runner as S

    sys.addaudithook(hook)
    ds = D.build_e2(0, 16, 1101)
    S.RSS_LIMIT = 8 * 1024 ** 3
    s = S.Session({'dataset': 'synthetic_e2', 'route': 'synthetic_control',
                   'schedule': 'W2_final_only', 'engine': 'B3-Lazy',
                   'core_h': 0, 'gap': 16, 'seed': 1101, 'block': 0})
    s.run_synthetic(ds)
    mods = {}
    for name, m in list(sys.modules.items()):
        f = getattr(m, '__file__', None)
        if f and str(f).startswith(str(PROJ)):
            mods[name] = str(pathlib.Path(f).resolve())
    third = []
    for name in ('numpy', 'shapely', 'rasterio', 'pyproj', 'psutil'):
        m = sys.modules.get(name)
        if m is not None:
            third.append({'name': name, 'version': getattr(m, '__version__', None)})
    print(json.dumps({'modules': mods, 'opened': sorted(opened), 'third_party': third,
                      'python': sys.version.split()[0]}))


if __name__ == '__main__':
    main()
