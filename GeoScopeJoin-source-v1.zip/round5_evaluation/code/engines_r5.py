"""Round 5 engines: full evaluation, eager and lazy maintenance, byte-capped cache.

All engines consume the same state (points, cells, grid, regions) and the same
explicit deltas (changed cell keys, changed point ids); nobody receives a
pre-chewed affected set. Semantic rows are cached as 5-field prefixes and the
source suffix is re-bound at every query, which is what makes a source-only
change observable.

Counters are split so that the fixed-point-set identity can be checked exactly:
    initial_eval, re_eval, new_eval, deleted_skip, fallback_eval, full_eval
"""
import collections
import math
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parents[1]
sys.path[:0] = [str(HERE / 'code'), str(HERE.parent / '.deps')]

from shapely.geometry import Point

import r5_common as C


def _cell_of(p, grid):
    return (math.floor((p[2] - grid['x0']) / grid['dx']),
            math.floor((p[3] - grid['y0']) / grid['dy']))


class _Base:
    name = 'base'

    def __init__(self, points, cells, grid, regions):
        self.points = points
        self.cells = cells
        self.grid = grid
        self.regions = regions
        self.c = {'initial_eval': 0, 're_eval': 0, 'new_eval': 0,
                  'deleted_skip': 0, 'fallback_eval': 0, 'full_eval': 0,
                  'dirty_peak': 0, 'affected_peak': 0, 'output_rows': 0}
        self._points_ref = set()

    # -- semantics ---------------------------------------------------------
    def _sem(self, pid):
        """Semantic rows for one point: region membership x cell lookup."""
        p = self.points[pid]
        cell = self.cells.get(_cell_of(p, self.grid))
        if cell is None:
            cid, status, val = None, 'NO_COVERAGE', None
        else:
            cid, val = cell
            status = 'NODATA' if val is None else 'OBSERVED'
        pt = Point(p[2], p[3])
        return [(gid, pid, cid, status, val)
                for gid, g in self.regions.items() if g.covers(pt)]

    def _bind(self, sem_rows, rv, pv, rh, ph):
        return [(r[0], r[1], r[2], r[3], r[4], rv, pv, rh, ph) for r in sem_rows]

    def _count_eval(self, pid, oldpoints):
        if pid in oldpoints:
            self.c['re_eval'] += 1
        else:
            self.c['new_eval'] += 1

    def counters(self):
        d = dict(self.c)
        d['semantic_eval'] = (d['initial_eval'] + d['re_eval'] + d['new_eval']
                              + d['fallback_eval'] + d['full_eval'])
        return d

    def close(self):
        pass


class BFullFast(_Base):
    """Re-evaluates every point per request; no index, no cross-query cache."""
    name = 'BFull-Fast'

    def update(self, oldpoints, newpoints, oldcells, newcells, changed_cells, changed_pids):
        self.c['deleted_skip'] += sum(1 for p in changed_pids if p in oldpoints and p not in newpoints)
        self.points = newpoints
        self.cells = newcells
        return {'affected': len(changed_pids)}

    def query(self, rv, pv, rh, ph):
        sem = []
        for pid in self.points:
            sem.extend(self._sem(pid))
            self.c['full_eval'] += 1
        rows = self._bind(sem, rv, pv, rh, ph)
        self.c['output_rows'] = len(rows)
        return rows

    def state_bytes(self):
        return {'index_bytes': 0, 'cache_bytes': 0}


class B3Eager(_Base):
    """Cell-to-point reverse index; affected points re-evaluated at each update."""
    name = 'B3-Eager'

    def __init__(self, points, cells, grid, regions):
        super().__init__(points, cells, grid, regions)
        self.reverse = collections.defaultdict(set)
        self.rows = {}
        t = time.perf_counter()
        for pid in points:
            self.reverse[_cell_of(points[pid], grid)].add(pid)
            self.rows[pid] = self._sem(pid)
            self.c['initial_eval'] += 1
        self.init_s = time.perf_counter() - t

    def update(self, oldpoints, newpoints, oldcells, newcells, changed_cells, changed_pids):
        t = time.perf_counter()
        deleted = [p for p in changed_pids if p in oldpoints and p not in newpoints]
        for pid in deleted:
            key = _cell_of(oldpoints[pid], self.grid)
            self.reverse[key].discard(pid)
            if not self.reverse[key]:
                self.reverse.pop(key, None)
            self.rows.pop(pid, None)
            self.c['deleted_skip'] += 1
        for pid in changed_pids:
            if pid in deleted:
                continue
            if pid in oldpoints:
                key = _cell_of(oldpoints[pid], self.grid)
                self.reverse[key].discard(pid)
                if not self.reverse[key]:
                    self.reverse.pop(key, None)
            if pid in newpoints:
                self.reverse[_cell_of(newpoints[pid], self.grid)].add(pid)
        affected = set()
        for key in changed_cells:
            affected |= self.reverse.get(key, set())
        affected |= {p for p in changed_pids if p in newpoints}
        self.points = newpoints
        self.cells = newcells
        for pid in affected:
            self.rows[pid] = self._sem(pid)
            self._count_eval(pid, oldpoints)
        self.c['affected_peak'] = max(self.c['affected_peak'], len(affected))
        self.update_s = getattr(self, 'update_s', 0.0) + (time.perf_counter() - t)
        return {'affected': len(affected)}

    def query(self, rv, pv, rh, ph):
        sem = [r for pid in self.rows for r in self.rows[pid]]
        rows = self._bind(sem, rv, pv, rh, ph)
        self.c['output_rows'] = len(rows)
        return rows

    def state_bytes(self):
        return {'index_bytes': C.deep_size(self.reverse) + C.deep_size(self.rows),
                'cache_bytes': 0}


class B3Lazy(B3Eager):
    """Same index granularity; evaluation deferred to the next query."""
    name = 'B3-Lazy'

    def __init__(self, points, cells, grid, regions):
        super().__init__(points, cells, grid, regions)
        self.dirty = set()

    def update(self, oldpoints, newpoints, oldcells, newcells, changed_cells, changed_pids):
        t = time.perf_counter()
        deleted = [p for p in changed_pids if p in oldpoints and p not in newpoints]
        for pid in deleted:
            key = _cell_of(oldpoints[pid], self.grid)
            self.reverse[key].discard(pid)
            if not self.reverse[key]:
                self.reverse.pop(key, None)
            self.rows.pop(pid, None)
            self.dirty.discard(pid)
            self.c['deleted_skip'] += 1
        for pid in changed_pids:
            if pid in deleted:
                continue
            if pid in oldpoints:
                key = _cell_of(oldpoints[pid], self.grid)
                self.reverse[key].discard(pid)
                if not self.reverse[key]:
                    self.reverse.pop(key, None)
            if pid in newpoints:
                self.reverse[_cell_of(newpoints[pid], self.grid)].add(pid)
            self.dirty.add(pid)
        for key in changed_cells:
            self.dirty |= self.reverse.get(key, set())
        self.points = newpoints
        self.cells = newcells
        self.c['dirty_peak'] = max(self.c['dirty_peak'], len(self.dirty))
        self.update_s = getattr(self, 'update_s', 0.0) + (time.perf_counter() - t)
        return {'affected': len(self.dirty), 'deferred': True}

    def query(self, rv, pv, rh, ph):
        oldpoints = self.points
        for pid in list(self.dirty):
            if pid in self.points:
                self.rows[pid] = self._sem(pid)
                self._count_eval(pid, oldpoints)
            else:
                self.rows.pop(pid, None)
        self.dirty.clear()
        return super().query(rv, pv, rh, ph)


class B3LazyDemandInit(B3Lazy):
    """Ablation: build only dependencies, evaluate semantics at the first query."""
    name = 'B3-Lazy-demand-init'

    def __init__(self, points, cells, grid, regions):
        _Base.__init__(self, points, cells, grid, regions)
        self.reverse = collections.defaultdict(set)
        self.rows = {}
        self.dirty = set(points)
        for pid in points:
            self.reverse[_cell_of(points[pid], grid)].add(pid)
        self.init_s = 0.0

    def query(self, rv, pv, rh, ph):
        for pid in list(self.dirty):
            if pid in self.points:
                fresh = pid not in self.rows
                self.rows[pid] = self._sem(pid)
                self.c['new_eval' if fresh else 're_eval'] += 1
            else:
                self.rows.pop(pid, None)
        self.dirty.clear()
        return B3Eager.query(self, rv, pv, rh, ph)


class B2Byte(_Base):
    """Tile cache with a hard retained-state byte budget.

    Tiles are 16x16 cells. Admission is constrained by measured retained state bytes
    (groups + cache), not by a guessed tile count. A tile larger than the budget is
    computed and streamed without retention; the budget is never silently enlarged.
    Accounting is incremental so that eviction does not re-traverse the whole graph.
    """
    name = 'B2-byte'

    def __init__(self, points, cells, grid, regions, budget_bytes):
        super().__init__(points, cells, grid, regions)
        self.budget = int(budget_bytes)
        self.groups = collections.defaultdict(dict)
        self.cache = collections.OrderedDict()
        self.tile = 16
        self.tile_bytes = {}
        self.peak_bytes = 0
        self.evictions = 0
        self.bypass = 0
        self.infeasible = False
        for pid, p in points.items():
            c = _cell_of(p, self.grid)
            self.groups[(c[0] // self.tile, c[1] // self.tile)][pid] = p
        self.groups_bytes = C.deep_size(self.groups)
        self.cache_bytes = 0
        if self.groups_bytes > self.budget:
            self.infeasible = True

    def _tile_of(self, key):
        return (key[0] // self.tile, key[1] // self.tile)

    def update(self, oldpoints, newpoints, oldcells, newcells, changed_cells, changed_pids):
        t = time.perf_counter()
        affected = {self._tile_of(k) for k in changed_cells}
        for pid in changed_pids:
            if pid in oldpoints:
                tile = self._tile_of(_cell_of(oldpoints[pid], self.grid))
                affected.add(tile)
                self.groups[tile].pop(pid, None)
                if not self.groups[tile]:
                    self.groups.pop(tile, None)
            if pid in newpoints:
                tile = self._tile_of(_cell_of(newpoints[pid], self.grid))
                affected.add(tile)
                self.groups[tile][pid] = newpoints[pid]
            if pid in oldpoints and pid not in newpoints:
                self.c['deleted_skip'] += 1
        for tile in affected:
            if self.cache.pop(tile, None) is not None:
                self.cache_bytes -= self.tile_bytes.pop(tile, 0)
        self.points = newpoints
        self.cells = newcells
        self.groups_bytes = C.deep_size(self.groups)
        self.c['affected_peak'] = max(self.c['affected_peak'], len(affected))
        self.peak_bytes = max(self.peak_bytes, self.groups_bytes + self.cache_bytes)
        self.update_s = getattr(self, 'update_s', 0.0) + (time.perf_counter() - t)
        return {'affected': len(affected)}

    def _evict_until_fit(self, extra):
        while self.cache and self.groups_bytes + self.cache_bytes + extra > self.budget:
            _tile, rows = self.cache.popitem(last=False)
            self.cache_bytes -= self.tile_bytes.pop(_tile, 0)
            self.evictions += 1

    def query(self, rv, pv, rh, ph):
        sem = []
        for tile in sorted(self.groups):
            if tile in self.cache:
                self.cache.move_to_end(tile)
                sem.extend(self.cache[tile])
                continue
            rows = []
            for pid in self.groups[tile]:
                rows.extend(self._sem(pid))
                self.c['re_eval'] += 1
            tile_b = C.deep_size(rows)
            if self.groups_bytes + self.cache_bytes + tile_b <= self.budget:
                self.cache[tile] = rows
                self.tile_bytes[tile] = tile_b
                self.cache_bytes += tile_b
                self._evict_until_fit(0)
                sem.extend(rows)
            else:
                self.bypass += 1
                sem.extend(rows)
            self.peak_bytes = max(self.peak_bytes, self.groups_bytes + self.cache_bytes)
        rows = self._bind(sem, rv, pv, rh, ph)
        self.c['output_rows'] = len(rows)
        return rows

    def state_bytes(self):
        return {'index_bytes': self.groups_bytes, 'cache_bytes': self.cache_bytes,
                'state_bytes': self.groups_bytes + self.cache_bytes,
                'peak_bytes': self.peak_bytes,
                'evictions': self.evictions, 'bypass': self.bypass,
                'infeasible': self.infeasible}


ENGINES = {'BFull-Fast': BFullFast, 'B3-Eager': B3Eager, 'B3-Lazy': B3Lazy,
           'B3-Lazy-demand-init': B3LazyDemandInit}


def make(name, points, cells, grid, regions, **kw):
    if name == 'B2-byte':
        return B2Byte(points, cells, grid, regions, kw['budget_bytes'])
    return ENGINES[name](points, cells, grid, regions)
