"""Freeze the execution closure and bind parameters (G0.2).

Closure = every project module actually imported during a representative session
(discovered in a subprocess through sys.modules), plus every file read at runtime
(discovered through a Python audit hook on `open`), plus the protocol, the parameter
matrix, the oracle artifacts and every registered input.

Paths are stored relative to the project root; verification resolves them from the
freeze, never from the shell working directory. Unknown project modules abort.
"""
import json
import pathlib
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code')]

import r5_common as C

CODE_PATTERNS = ('*.py',)


def declared_project_files():
    files = set()
    for pat in CODE_PATTERNS:
        files |= set((HERE / 'code').glob(pat))
        files |= set((HERE / 'tests').glob(pat))
    for p in (HERE / 'protocols').rglob('*'):
        if p.is_file():
            files.add(p)
    for p in (HERE / 'manifests').glob('*.json'):
        files.add(p)
    return files


def discover_runtime():
    """Run a representative session in a subprocess and report what it touched."""
    out = subprocess.run([sys.executable, '-I', str(HERE / 'code' / 'discover_reads.py')],
                         capture_output=True, text=True, cwd=str(PROJ), timeout=600)
    if out.returncode != 0:
        raise RuntimeError('discovery pass failed: %s' % (out.stderr[-800:],))
    return json.loads(out.stdout.strip().splitlines()[-1])


def build(files, params, extra=None):
    entries = {}
    for f in sorted(set(files)):
        p = pathlib.Path(f).resolve()
        if not p.is_file():
            continue
        try:
            rel = p.relative_to(PROJ).as_posix()
        except ValueError:
            continue
        entries[rel] = {'sha256': C.sha256_file(p), 'bytes': p.stat().st_size}
    doc = {
        'schema': 'geoscopejoin-round5-freeze-v1',
        'project_root': str(PROJ),
        'files': entries,
        'params': params,
        'params_sha256': C.sha256_bytes(json.dumps(params, sort_keys=True).encode()),
        'extra': extra or {},
    }
    return doc


def verify(doc, project_root=None, overrides=None):
    root = pathlib.Path(project_root or doc['project_root'])
    overrides = overrides or {}
    problems = []
    files = dict(doc['files'])
    for rel, rec in sorted(files.items()):
        p = pathlib.Path(overrides[rel]) if rel in overrides else root / rel
        if not p.is_file():
            problems.append('missing: %s' % rel)
            continue
        if C.sha256_file(p) != rec['sha256']:
            problems.append('hash mismatch: %s' % rel)
    if C.sha256_bytes(json.dumps(doc['params'], sort_keys=True).encode()) != doc['params_sha256']:
        problems.append('parameter block changed')
    return problems


# ------------------------------------------------------------ parameter binding
ROUTES = {'raw_service', 'registered_service'}
SCHEDULES = {'W2_final_only', 'W3_each_state'}
ENGINES = {'BFull-Fast', 'B3-Eager', 'B3-Lazy', 'B3-Lazy-demand-init', 'B2-byte'}


def parameters_match(cfg, matrix):
    """Compare a realized session config against the frozen matrix."""
    problems = []
    e1 = matrix['E1']
    if cfg.get('dataset') not in e1['datasets']:
        problems.append('dataset not in matrix: %r' % cfg.get('dataset'))
    if cfg.get('route') not in ROUTES:
        problems.append('route not in matrix')
    if cfg.get('schedule') not in SCHEDULES:
        problems.append('schedule not in matrix')
    if cfg.get('engine') not in ENGINES:
        problems.append('engine not in matrix')
    if not (0 <= int(cfg.get('block', -1)) < e1['blocks']):
        problems.append('block out of preregistered range')
    H = int(cfg.get('H', 1))
    if H not in e1['amortization']['H']:
        problems.append('H not preregistered')
    return problems
