"""Round 5 shared primitives.

Frozen at protocol time: grid, region layout, encodings, row layout, phase timer.

Row layout (unchanged from the audited contract):
    (gid, pid, cid, status, val, rv, pv, rh, ph)
- status in {OBSERVED, NODATA, NO_COVERAGE}
- val is an exact encoded integer (units/2^32) or a 16-hex-digit binary64 pattern, or None
- rh is the SHA-256 of the source ZIP the raster window was decoded from
- ph is the SHA-256 of the point source file

Nothing in this module reads round2/round3/round4 code. Datasets are read as data
(ZIP, NPY, JSON) and every such file is registered in the freeze.
"""
import contextlib, hashlib, json, math, pathlib, struct, sys, time
from fractions import Fraction

HERE = pathlib.Path(__file__).resolve().parents[1]        # round5_evaluation
PROJ = HERE.parent                                        # GeoScopeJoin
DEPS = PROJ / '.deps'
if str(DEPS) not in sys.path:
    sys.path.insert(0, str(DEPS))

NODATA_SENTINEL = -200.0
CRS = 'ESRI:54009'
DX = DY = 100.0
UNITS_SCALE = 1 << 32


# ---------------------------------------------------------------- hashing / IO
def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_npy(arr):
    """SHA-256 of the .npy encoding of arr (identical bytes to np.save)."""
    import io
    import numpy as np
    buf = io.BytesIO()
    np.save(buf, arr, allow_pickle=False)
    return sha256_bytes(buf.getvalue())


def read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding='utf-8'))


def write_json(path, obj):
    p = pathlib.Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding='utf-8')
    return p


def create_run_dir(root, config_hash, label=''):
    """Exclusive run directory; refuses to reuse an existing one."""
    stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
    name = '%s_%s%s' % (stamp, config_hash[:12], ('_' + label) if label else '')
    d = pathlib.Path(root) / name
    d.mkdir(parents=True, exist_ok=False)
    return d


# ------------------------------------------------------------------- encoding
def encode_units(value):
    """Exact units/2^32 encoding.

    Rejection reasons are explicit:
      - non-finite valid value
      - negative zero (no distinct representation in an integer encoding)
      - exact binary denominator that does not divide 2^32
    """
    f = float(value)
    if math.isnan(f) or math.isinf(f):
        raise ValueError('non-finite valid value has no integer encoding')
    if f == 0.0 and math.copysign(1.0, f) < 0:
        raise ValueError('negative zero has no distinct units/2^32 representation')
    frac = Fraction(f)
    den = frac.denominator
    if UNITS_SCALE % den:
        raise ValueError('exact binary denominator %d does not divide 2^32' % den)
    return frac.numerator * (UNITS_SCALE // den)


def encode_hex_candidate(value):
    """Candidate encoder for the alternative encoding (binary64 pattern, hex)."""
    return struct.pack('<d', float(value)).hex()


def encode_native(value, encoding):
    """Native reference encoder: independent of the candidate encoder.

    'units' -> exact Fraction arithmetic; 'hex' -> bit view, not struct.pack.
    """
    import numpy as np
    f = float(value)
    if math.isnan(f) or math.isinf(f):
        raise ValueError('non-finite valid value')
    if encoding == 'units':
        if f == 0.0 and math.copysign(1.0, f) < 0:
            raise ValueError('negative zero')
        frac = Fraction(f)
        if UNITS_SCALE % frac.denominator:
            raise ValueError('denominator does not divide 2^32')
        return frac.numerator * (UNITS_SCALE // frac.denominator)
    if encoding == 'hex':
        bits = int(np.array(f, dtype=np.float64).view(np.uint64))
        return bits.to_bytes(8, 'little').hex()
    raise ValueError('unknown encoding %r' % (encoding,))


def encodable_units(values):
    """True when every value is exactly representable by units/2^32."""
    for v in values:
        try:
            encode_units(v)
        except ValueError:
            return False
    return True


def encode_array(arr, nodata, encoding):
    """Native array -> cells dict {(col, row_bottom_up): (cid, val)}.

    cid is '<tiff_row>:<col>' with tiff_row measured from the top of the window.
    """
    h, w = arr.shape
    cells = {}
    for r in range(h):
        row_bu = h - 1 - r
        for c in range(w):
            v = arr[r, c]
            if v == nodata:
                cells[(c, row_bu)] = ('%d:%d' % (r, c), None)
            elif encoding == 'units':
                cells[(c, row_bu)] = ('%d:%d' % (r, c), encode_units(v))
            else:
                cells[(c, row_bu)] = ('%d:%d' % (r, c), encode_hex_candidate(v))
    return cells


# --------------------------------------------------------------- grid / regions
def grid_of(x0, y0, window, dx=DX, dy=DY, window_h=None, window_w=None):
    h = int(window_h if window_h is not None else window)
    w = int(window_w if window_w is not None else window)
    return {'x0': float(x0), 'y0': float(y0), 'dx': float(dx), 'dy': float(dy),
            'window': max(h, w), 'window_h': h, 'window_w': w, 'crs': CRS}


def regions_proportional(x0, y0, window, dx=DX, dy=DY, count=3):
    """Region layout expressed as fractions of the window (works at any scale).

    The 3-region layout reproduces the audited round3 layout exactly at 256 cells:
    whole window; shell with a hole from 0.375 to 0.625; two-part multipolygon
    (0..0.3125 and 0.6875..1).
    """
    from shapely.geometry import box, Polygon, MultiPolygon
    w = window * dx
    h = window * dy
    if count == 3:
        return {
            'whole': box(x0, y0, x0 + w, y0 + h),
            'hole': Polygon([(x0, y0), (x0 + w, y0), (x0 + w, y0 + h), (x0, y0 + h)],
                            holes=[[(x0 + 0.375 * w, y0 + 0.375 * h), (x0 + 0.625 * w, y0 + 0.375 * h),
                                    (x0 + 0.625 * w, y0 + 0.625 * h), (x0 + 0.375 * w, y0 + 0.625 * h)]]),
            'multi': MultiPolygon([box(x0, y0, x0 + 0.3125 * w, y0 + 0.3125 * h),
                                   box(x0 + 0.6875 * w, y0 + 0.6875 * h, x0 + w, y0 + h)]),
        }
    # generic layout for scale tests: count equal vertical bands plus the whole window
    regs = {'whole': box(x0, y0, x0 + w, y0 + h)}
    for i in range(count - 1):
        lo = x0 + (i / (count - 1)) * w
        hi = x0 + ((i + 1) / (count - 1)) * w
        regs['band%03d' % i] = box(lo, y0, hi, y0 + h)
    return regs


def regions_wkb_sha(regions):
    h = hashlib.sha256()
    for gid, g in sorted(regions.items()):
        h.update(gid.encode())
        h.update(g.wkb)
    return h.hexdigest()


# --------------------------------------------------------------------- rows
def rows_digest(rows):
    return sha256_bytes(json.dumps(sorted(rows), separators=(',', ':')).encode())


def canonical_bytes(rows):
    return json.dumps(sorted(rows), separators=(',', ':')).encode()


# -------------------------------------------------------------------- timing
class PhaseTimer:
    """One outer wall timer plus mutually exclusive named phases.

    Nested work must be recorded as a sub-phase (recorded but never added to the
    top-level sum). `total()` is the outer wall, not the sum of phases.
    """

    def __init__(self):
        self.t0 = time.perf_counter()
        self.phases = {}
        self.sub = {}
        self._stack = []

    @contextlib.contextmanager
    def phase(self, name):
        t = time.perf_counter()
        try:
            yield
        finally:
            self.phases[name] = self.phases.get(name, 0.0) + (time.perf_counter() - t)

    @contextlib.contextmanager
    def subphase(self, name):
        t = time.perf_counter()
        try:
            yield
        finally:
            self.sub[name] = self.sub.get(name, 0.0) + (time.perf_counter() - t)

    def total(self):
        return time.perf_counter() - self.t0

    def closure(self):
        total = self.total()
        s = sum(self.phases.values())
        return {'total_s': total, 'phase_sum_s': s,
                'residual_s': total - s,
                'residual_fraction': abs(total - s) / total if total else 0.0,
                'phases_s': dict(self.phases), 'subphases_s': dict(self.sub)}


# --------------------------------------------------------------- object sizes
def deep_size(obj, _seen=None):
    """Retained bytes over one object graph; shared objects are counted once."""
    import collections.abc
    if _seen is None:
        _seen = set()
    oid = id(obj)
    if oid in _seen:
        return 0
    _seen.add(oid)
    try:
        size = sys.getsizeof(obj)
    except TypeError:
        return 0
    if isinstance(obj, dict):
        for k, v in obj.items():
            size += deep_size(k, _seen) + deep_size(v, _seen)
    elif isinstance(obj, (list, tuple, set, frozenset, collections.abc.KeysView)):
        for v in obj:
            size += deep_size(v, _seen)
    elif hasattr(obj, '__dict__'):
        size += deep_size(obj.__dict__, _seen)
    return size


def rss_bytes():
    try:
        import psutil
        return psutil.Process().memory_info().rss
    except Exception:
        return None


def peak_rss_bytes():
    try:
        import psutil
        return psutil.Process().memory_info().rss, getattr(psutil.Process().memory_info(), 'peak_wset', None)
    except Exception:
        return None, None
