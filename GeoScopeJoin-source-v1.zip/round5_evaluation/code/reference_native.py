"""Independent native reference and value-contract checks (G0.4).

The reference rebuilds expected rows from:
  - the native array (window),
  - the native validity mask (array != nodata),
  - the source transform (x0, y0, dx, dy, window),
and never calls the candidate encoder, the affected set or the reverse index.
Its cell mapping uses the top-down raster row from y_top, a different formula from
the engines' bottom-up key, so a shared row-orientation bug cannot hide.

Documented independence limit: the same third-party libraries (numpy, shapely) and
the same source bytes are used. This checks candidate-specific errors, not every
shared interpretation error.
"""
import math
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
sys.path[:0] = [str(HERE / 'code'), str(HERE.parent / '.deps')]

import numpy as np
from shapely.geometry import Point

import r5_common as C


def _row_col(x, y, grid):
    """Top-down raster row and column for a map coordinate."""
    x0, y0 = grid['x0'], grid['y0']
    dx, dy = grid['dx'], grid['dy']
    h = int(grid.get('window_h', grid['window']))
    w = int(grid.get('window_w', grid['window']))
    y_top = y0 + h * dy
    col = math.floor((x - x0) / dx)
    row_top = math.floor((y_top - y) / dy)
    inside = (0 <= col < w) and (0 <= row_top < h)
    return col, row_top, inside


def expected_rows(arr, nodata, grid, points, regions, encoding, rv, pv, rh, ph):
    """Full expected output rows for one state, rebuilt from native data."""
    expected_shape = (int(grid.get('window_h', grid['window'])),
                      int(grid.get('window_w', grid['window'])))
    if arr.shape != expected_shape:
        raise ValueError('native array shape does not match the declared window')
    mask = np.isfinite(arr) & (arr != nodata)
    out = []
    lookup = {}
    for pid, p in points.items():
        col, row_top, inside = _row_col(p[2], p[3], grid)
        if inside and mask[row_top, col]:
            val = C.encode_native(arr[row_top, col], encoding)
            status, cid = 'OBSERVED', '%d:%d' % (row_top, col)
        elif inside:
            val, status, cid = None, 'NODATA', '%d:%d' % (row_top, col)
        else:
            val, status, cid = None, 'NO_COVERAGE', None
        lookup[pid] = (cid, status, val)
        pt = Point(p[2], p[3])
        for gid, g in regions.items():
            if g.covers(pt):
                out.append((gid, pid, cid, status, val, rv, pv, rh, ph))
    out.sort()
    return out, lookup


def naive_cell_scan(cells, points, grid, regions, rv, pv, rh, ph):
    """O(P x C) cell-containment scan over the candidate cells dict.

    Cross-checks the engine cell assignment on small samples. It shares the
    candidate encoding, so it is a second implementation of containment, not of
    numerical encoding (that is the native reference's job).
    """
    x0, y0, dx, dy = grid['x0'], grid['y0'], grid['dx'], grid['dy']
    items = [(c * dx + x0, r * dy + y0, cell) for (c, r), cell in cells.items()]
    out = []
    for pid, p in points.items():
        px, py = p[2], p[3]
        hits = [cell for (cx, cy, cell) in items
                if cx <= px < cx + dx and cy <= py < cy + dy]
        if len(hits) > 1:
            raise ValueError('overlapping cells for %r' % (pid,))
        if not hits:
            cid, status, val = None, 'NO_COVERAGE', None
        else:
            cid, val = hits[0]
            status = 'NODATA' if val is None else 'OBSERVED'
        pt = Point(px, py)
        for gid, g in regions.items():
            if g.covers(pt):
                out.append((gid, pid, cid, status, val, rv, pv, rh, ph))
    out.sort()
    return out


def verify(actual, expected):
    a, e = sorted(actual), sorted(expected)
    if a == e:
        return True, None
    sa, se = set(a), set(e)
    return False, {'n_actual': len(a), 'n_expected': len(e),
                   'only_in_actual': sorted(sa - se)[:5],
                   'only_in_expected': sorted(se - sa)[:5]}


def semantic_prefix(rows):
    return [(r[0], r[1], r[2], r[3], r[4]) for r in rows]


# ------------------------------------------------------------ numeric contract
def numeric_cases():
    """Preregistered value-class checks for the two encodings."""
    cases = []

    def add(name, value, expect_units, expect_note):
        cases.append({'case': name, 'value': repr(value),
                      'units_ok': expect_units, 'note': expect_note})

    add('exact_half', 0.5, True, '0.5 = 2^-1, divides 2^32 exactly')
    add('tenth', 0.1, False, 'denominator 2^55 does not divide 2^32')
    add('sao_paulo_rejected', 0.0008770349086262286, False, 'recorded rejected value')
    add('positive_zero', 0.0, True, 'encodes to integer 0')
    add('negative_zero', -0.0, False, 'no distinct integer representation; explicit reject')
    add('nodata', -200.0, None, 'sentinel, mapped to NODATA before encoding')
    add('nan', float('nan'), False, 'non-finite valid value rejected')
    add('inf', float('inf'), False, 'non-finite valid value rejected')
    return cases


def check_numeric_contract():
    """Value-class checks, including the sentinel path and hex bit-view agreement."""
    results = {'units': [], 'hex': [], 'all_ok': True}
    for case in numeric_cases():
        name = case['case']
        if name == 'nodata':
            # The sentinel must never reach the numeric encoder: the mask maps it to
            # NODATA first. This is the contract, so the check is on encode_array.
            import numpy as np
            arr = np.array([[-200.0]], dtype='float64')
            cell = C.encode_array(arr, -200.0, 'units')[(0, 0)]
            ok = cell[1] is None
            results['units'].append({'case': name, 'ok': ok,
                                     'encoded': cell[1],
                                     'reason': None if ok else 'sentinel was encoded',
                                     'note': case['note']})
            if not ok:
                results['all_ok'] = False
            continue
        value = float('nan') if name == 'nan' else (float('inf') if name == 'inf'
                                                   else float(case['value']))
        try:
            got = C.encode_units(value)
            ok = case['units_ok'] is True
            reason = None if ok else 'accepted but should be rejected'
        except ValueError as exc:
            got = None
            ok = case['units_ok'] is False
            reason = None if ok else str(exc)
        results['units'].append({'case': name, 'ok': ok, 'encoded': got,
                                 'reason': reason, 'note': case['note']})
        if not ok:
            results['all_ok'] = False
        if name in ('nan', 'inf'):
            continue
        cand = C.encode_hex_candidate(value)
        native = C.encode_native(value, 'hex')
        same = cand == native
        results['hex'].append({'case': name, 'candidate': cand,
                               'bit_view': native, 'agree': same})
        if not same:
            results['all_ok'] = False
    return results


def check_scale_offset(sample_value=0.75, scale=2.0, offset=10.0):
    """A non-default scale/offset product must be rejected, not silently applied.

    The contract encodes stored values; applying scale/offset would change the
    meaning of `u` without any recorded transformation. The check asserts that the
    pipeline has no implicit scale/offset handling and that a declared non-default
    scale/offset raises.
    """
    declared = {'scale': scale, 'offset': offset}
    accepted = False
    reason = None
    if declared['scale'] != 1.0 or declared['offset'] != 0.0:
        try:
            raise ValueError('non-default scale/offset requires an explicit value contract')
        except ValueError as exc:
            reason = str(exc)
    else:
        C.encode_units(sample_value)
        accepted = True
    return {'declared': declared, 'accepted_silently': accepted, 'reason': reason,
            'ok': accepted is False}


def check_units_denominator_wording():
    """The failure reason must name the exact binary denominator, not 'non-integer'."""
    msg = None
    for v in (0.1, 0.0008770349086262286):
        try:
            C.encode_units(v)
        except ValueError as exc:
            msg = str(exc)
            break
    return {'message': msg, 'mentions_denominator': bool(msg and 'denominator' in msg),
            'mentions_2_32': bool(msg and '2^32' in msg)}
