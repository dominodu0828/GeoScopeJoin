"""E1: two complete service routes, paired blocks, amortization.

Matrix: 2 datasets x 2 routes x 2 schedules x 3 engines x 30 data blocks
        (+3 smoke blocks per configuration, excluded from analysis).
Sessions run one at a time in their own process; wall time is measured outside the
child (spawn -> artifact complete).

Usage:
  python -I run_e1.py --datasets shenzhen --blocks 30 --smoke 3
  python -I run_e1.py --amortization
"""
import argparse
import json
import pathlib
import random
import subprocess
import sys
import time

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code')]

import r5_common as C
import freeze_closure as FZ
import summarize as S

DATASETS = ['shenzhen_same_epoch_release_pair', 'sao_paulo_cross_epoch_published_grids']
ROUTES = ['raw_service', 'registered_service']
SCHEDULES = ['W2_final_only', 'W3_each_state']
ENGINES = ['BFull-Fast', 'B3-Eager', 'B3-Lazy']
SEED = 20261110


def run_child(cfg, out_path, timeout=120):
    cp = pathlib.Path(cfg['run_dir'])
    cp.mkdir(parents=True, exist_ok=True)
    cfg_path = cp / 'config.json'
    C.write_json(cfg_path, cfg)
    t0 = time.perf_counter()
    try:
        p = subprocess.run([sys.executable, '-I', str(HERE / 'code' / 'session_runner.py'),
                            '--config', str(cfg_path), '--out', str(out_path)],
                           capture_output=True, text=True, timeout=timeout, cwd=str(PROJ))
        rc = p.returncode
        tail = (p.stdout or '').strip().splitlines()[-1:] or ['']
    except subprocess.TimeoutExpired:
        rc = -9
        tail = ['timeout']
    wall = time.perf_counter() - t0
    if out_path.is_file():
        rec = C.read_json(out_path)
    else:
        rec = {'status': 'RESOURCE_LIMIT' if rc == -9 else 'CRASH',
               'problems': ['no artifact; rc=%s %s' % (rc, tail)], 'timers': {},
               'query_checks': [], 'counters': {}}
    rec['spawn_wall_s'] = wall
    rec['config'] = cfg
    C.write_json(out_path, rec)
    return rec


def session_id(cfg, retry=0):
    h = int(cfg.get('H', 1))
    return '%s__%s__%s__%s__b%02d%s%s' % (cfg['dataset'].split('_')[0], cfg['route'],
                                          cfg['schedule'], cfg['engine'], cfg['block'],
                                          '_H%d' % h if h > 1 else '',
                                          '_r%d' % retry if retry else '')


def one(cfg, outdir, retries=1):
    sid = session_id(cfg)
    out = outdir / 'sessions' / (sid + '.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    rec = run_child(cfg, out)
    if rec['status'] != 'PASS' and retries and rec['status'] in ('TIMING_INVALID', 'CRASH',
                                                                'RESOURCE_LIMIT'):
        cfg2 = dict(cfg)
        cfg2['run_dir'] = cfg['run_dir'] + '_retry'
        rec2 = run_child(cfg2, outdir / 'sessions' / (sid + '_r1.json'))
        rec2['retried_from'] = rec['status']
        if rec2['status'] == 'PASS':
            return rec2, rec
        return rec2, rec
    return rec, None


def summarize_group(records):
    d = S.distribution(records)
    out = {'census': d['census'], 'n_valid': d['n_valid'], 'n_total': d['n_total']}
    r = S.paired_ratios(records, 'B3-Lazy', 'B3-Eager')
    if r:
        out['lazy_over_eager'] = r
    r2 = S.paired_ratios(records, 'BFull-Fast', 'B3-Eager')
    if r2:
        out['full_over_eager'] = r2
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--datasets', default='all')
    ap.add_argument('--blocks', type=int, default=30)
    ap.add_argument('--smoke', type=int, default=3)
    ap.add_argument('--amortization', action='store_true')
    ap.add_argument('--only-amortization', action='store_true')
    ap.add_argument('--limit', type=int, default=0)
    a = ap.parse_args()

    freeze = C.read_json(HERE / 'manifests' / 'freeze_g0.json')
    problems = FZ.verify(freeze)
    if problems:
        print(json.dumps({'FREEZE_FAIL': problems[:5]}))
        return 2
    matrix = C.read_json(HERE / 'protocols' / 'matrix.json')
    config_hash = C.sha256_file(HERE / 'protocols' / 'matrix.json')
    run_dir = C.create_run_dir(HERE / 'runs', config_hash, 'e1_amort' if a.only_amortization else 'e1')
    ds_list = DATASETS if a.datasets == 'all' else [d for d in DATASETS if d.startswith(a.datasets)]
    records, retried = [], []
    t_start = time.perf_counter()

    if not a.only_amortization:
        total = len(ds_list) * len(ROUTES) * len(SCHEDULES) * len(ENGINES) * (a.blocks + a.smoke)
        print('E1 base matrix: %d sessions' % total)
        n = 0
        for ds in ds_list:
            for route in ROUTES:
                for sched in SCHEDULES:
                    for block in range(a.blocks + a.smoke):
                        order = list(ENGINES)
                        random.Random(SEED + block * 7919).shuffle(order)
                        for eng in order:
                            n += 1
                            cfg = {'dataset': ds, 'route': route, 'schedule': sched,
                                   'engine': eng, 'block': block, 'H': 1,
                                   'run_dir': str(run_dir / 'work' / session_id(
                                       {'dataset': ds, 'route': route, 'schedule': sched,
                                        'engine': eng, 'block': block}))}
                            pm = FZ.parameters_match(cfg, matrix)
                            rec, old = one(cfg, run_dir)
                            rec['parameters_match'] = (pm == [])
                            rec['smoke'] = block < a.smoke
                            records.append(rec)
                            if old is not None:
                                retried.append({'session': session_id(cfg),
                                                'first': old['status'], 'second': rec['status']})
                            if n % 20 == 0:
                                print('  %d/%d  last=%s %s %.3fs' % (n, total, rec['config']['engine'],
                                      rec['status'], rec['spawn_wall_s']), flush=True)
                            if a.limit and n >= a.limit:
                                break

    if a.amortization or a.only_amortization:
        print('E1 amortization: registered route, W2, H in {1,10,100}')
        for ds in ds_list:
            for eng in ('B3-Eager', 'B3-Lazy'):
                for H in (10, 100):
                    for block in range(10):
                        cfg = {'dataset': ds, 'route': 'registered_service',
                               'schedule': 'W2_final_only', 'engine': eng,
                               'block': block, 'H': H,
                               'run_dir': str(run_dir / 'work' / ('amort_%s_%s_H%d_b%d' % (
                                   ds.split('_')[0], eng, H, block)))}
                        pm = FZ.parameters_match(cfg, matrix)
                        rec, old = one(cfg, run_dir)
                        rec['parameters_match'] = (pm == [])
                        rec['smoke'] = False
                        records.append(rec)
                        if old is not None:
                            retried.append({'session': session_id(cfg), 'first': old['status'],
                                            'second': rec['status']})

    # analysis excludes smoke blocks
    # smoke blocks and amortization replays (H>1) never enter the paired base analysis
    data = [r for r in records if not r.get('smoke') and int(r['config'].get('H', 1)) == 1]
    groups = {}
    for r in data:
        c = r['config']
        key = '%s|%s|%s' % (c['dataset'], c['route'], c['schedule'])
        groups.setdefault(key, []).append(r)
    report = {'phase': 'E1', 'run_dir': str(run_dir.relative_to(PROJ).as_posix()),
              'protocol': 'protocols/R5_PROTOCOL.md',
              'freeze_sha256': C.sha256_file(HERE / 'manifests' / 'freeze_g0.json'),
              'n_sessions': len(records), 'n_data': len(data),
              'n_smoke': len(records) - len(data), 'retried': retried,
              'environment': {'python': sys.version.split()[0]},
              'groups': {}, 'route_comparison': {}, 'amortization': {},
              'wall_s': round(time.perf_counter() - t_start, 1)}

    for key, recs in sorted(groups.items()):
        report['groups'][key] = summarize_group(recs)
        print(key, json.dumps({k: v for k, v in report['groups'][key].items()
                               if k != 'census'}), flush=True)

    # route comparison: registered service cost vs raw service cost, same block
    for ds in ds_list:
        for sched in SCHEDULES:
            for eng in ENGINES:
                by_block = {}
                for r in data:
                    c = r['config']
                    if c['dataset'] == ds and c['schedule'] == sched and c['engine'] == eng:
                        by_block.setdefault(c['block'], {})[c['route']] = r
                pairs = []
                for block, per in by_block.items():
                    a_raw = S.service_total(per.get('raw_service')) if per.get('raw_service') else None
                    a_reg = S.service_total(per.get('registered_service')) if per.get('registered_service') else None
                    if a_raw and a_reg:
                        pairs.append(a_reg / a_raw)
                if pairs:
                    import statistics
                    report['route_comparison']['%s|%s|%s' % (ds, sched, eng)] = {
                        'n': len(pairs), 'median_registered_over_raw': statistics.median(pairs),
                        'min': min(pairs), 'max': max(pairs)}

    # amortization: T_total(H) = T_register + sum online
    for r in data:
        c = r['config']
        if c['route'] != 'registered_service' or c.get('H', 1) not in (10, 100):
            continue
        t = r.get('timers') or {}
        reg = (t.get('register') or {}).get('total_s')
        on = t.get('online_total_s')
        key = '%s|%s' % (c['dataset'], c['engine'])
        report['amortization'].setdefault(key, {}).setdefault('H%d' % c['H'], [])
        if reg is not None and on is not None:
            report['amortization'][key]['H%d' % c['H']].append(
                {'register_s': reg, 'online_s': on, 'register_share': reg / (reg + on)})
    for key, per in report['amortization'].items():
        for h, rows in per.items():
            if rows:
                import statistics
                per[h] = {'n': len(rows),
                          'median_register_s': statistics.median(r['register_s'] for r in rows),
                          'median_online_s': statistics.median(r['online_s'] for r in rows),
                          'median_register_share': statistics.median(r['register_share'] for r in rows)}
        base = per.get('H1') or {}
        for h in ('H10', 'H100'):
            if isinstance(per.get(h), dict) and base.get('median_register_s'):
                per[h]['speedup_vs_H1_total'] = ((base['median_register_s'] + base['median_online_s'])
                                                 / (per[h]['median_register_s'] + per[h]['median_online_s']))

    # H=1 baseline from the base matrix for the same cells
    for r in data:
        c = r['config']
        if c['route'] == 'registered_service' and c.get('H', 1) == 1 and c['schedule'] == 'W2_final_only':
            t = r.get('timers') or {}
            reg = (t.get('register') or {}).get('total_s')
            on = t.get('online_total_s')
            if reg is None or on is None:
                continue
            key = '%s|%s' % (c['dataset'], c['engine'])
            report['amortization'].setdefault(key, {}).setdefault('H1', [])
            report['amortization'][key]['H1'].append(
                {'register_s': reg, 'online_s': on, 'register_share': reg / (reg + on)})
    for key, per in report['amortization'].items():
        rows = per.get('H1')
        if isinstance(rows, list) and rows:
            import statistics
            per['H1'] = {'n': len(rows),
                         'median_register_s': statistics.median(r['register_s'] for r in rows),
                         'median_online_s': statistics.median(r['online_s'] for r in rows),
                         'median_register_share': statistics.median(r['register_share'] for r in rows)}
            base = per['H1']
            for h in ('H10', 'H100'):
                if isinstance(per.get(h), dict):
                    per[h]['speedup_vs_H1_total'] = ((base['median_register_s'] + base['median_online_s'])
                                                     / (per[h]['median_register_s'] + per[h]['median_online_s']))

    C.write_json(HERE / 'reports' / 'e1_report.json', report)
    # keep a copy inside the run directory for provenance
    C.write_json(run_dir / 'e1_report.json', report)
    print('wrote reports/e1_report.json  sessions=%d wall=%.0fs' % (len(records), report['wall_s']))
    return 0


if __name__ == '__main__':
    sys.exit(main())
