"""E2: overlap x query-gap mechanism boundary.

Phase A (counts): 3 cores x 3 gaps x 5 layout seeds x {B3-Eager, B3-Lazy}; the measured
counters must match
    C_E = n + sum_t |A_t|,   C_L = n + sum_j |union_{t in B_j} A_t|
with zero residual, and every queried state must match the native reference.

Phase B (timing): the three preregistered endpoints, 30 paired sessions each.

Phase C (ablations): B3-Lazy-demand-init and a two-points-per-cell layout at the two
h endpoints, separating object count from cell count.
"""
import argparse
import json
import pathlib
import random
import statistics
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code')]

import r5_common as C
import datasets_r5 as D
import freeze_closure as FZ
import summarize as S
import session_runner as SR
import run_e1 as R1

CORES = [0, 128, 256]
GAPS = [1, 4, 16]
SEEDS = [1101, 1102, 1103, 1104, 1105]
ENDPOINTS = [(0, 16), (256, 1), (256, 16)]
SEED_STAT = 20261110


def counts(cores=None, gaps=None, seeds=None):
    rows = []
    for h in (cores or CORES):
        for gap in (gaps or GAPS):
            for seed in (seeds or SEEDS):
                ds = D.build_e2(h, gap, seed)
                for eng in ('B3-Eager', 'B3-Lazy'):
                    cfg = {'dataset': 'synthetic_e2', 'route': 'synthetic_control',
                           'schedule': 'W2_final_only', 'engine': eng,
                           'core_h': h, 'gap': gap, 'seed': seed, 'block': 0,
                           'run_dir': str(HERE / 'runs' / '_e2_counts')}
                    s = SR.Session(cfg)
                    s.run_synthetic(ds)
                    status = s.verdict()
                    rows.append({'core_h': h, 'gap': gap, 'seed': seed, 'engine': eng,
                                 'status': status,
                                 'semantic_eval': s.counters['semantic_eval'],
                                 'predicted': s.counters.get('predicted_total'),
                                 'residual': s.counters.get('predicted_residual'),
                                 'checks_ok': all(c['ok'] for c in s.checks),
                                 'queries': s.counters.get('queries')})
    residual_bad = [r for r in rows if r['residual'] not in (0, None)]
    return {'rows': rows,
            'n': len(rows),
            'all_correct': all(r['status'] == 'PASS' for r in rows),
            'max_abs_residual': max(abs(r['residual'] or 0) for r in rows),
            'residuals_nonzero': len(residual_bad),
            'summary': _count_table(rows),
            'combinations': {'cores': cores or CORES, 'gaps': gaps or GAPS,
                             'seeds': seeds or SEEDS}}


def _count_table(rows):
    out = []
    for h in CORES:
        for gap in GAPS:
            per = [r for r in rows if r['core_h'] == h and r['gap'] == gap]
            e = [r for r in per if r['engine'] == 'B3-Eager']
            l = [r for r in per if r['engine'] == 'B3-Lazy']
            out.append({'core_h': h, 'gap': gap,
                        'C_E': e[0]['predicted'] if e else None,
                        'C_L': l[0]['predicted'] if l else None,
                        'measured_E': e[0]['semantic_eval'] if e else None,
                        'measured_L': l[0]['semantic_eval'] if l else None,
                        'saving_fraction': (None if not (e and l) else
                                            1 - l[0]['semantic_eval'] / e[0]['semantic_eval'])})
    return out


def ablation():
    out = {'demand_init': [], 'two_points_per_cell': []}
    for h, gap in ENDPOINTS:
        ds = D.build_e2(h, gap, 1101)
        for eng in ('B3-Lazy-demand-init',):
            cfg = {'dataset': 'synthetic_e2', 'route': 'synthetic_control',
                   'schedule': 'W2_final_only', 'engine': eng, 'core_h': h,
                   'gap': gap, 'seed': 1101, 'block': 0,
                   'run_dir': str(HERE / 'runs' / '_e2_counts')}
            s = SR.Session(cfg)
            s.run_synthetic(ds)
            # Demand init evaluates the first query's affected set inside the full
            # materialization, so it appears once rather than twice:
            #   expected = C_L - |union of the first query group|
            expected = (ds['predicted']['C_L'] - ds['predicted']['union_per_query'][0])
            out['demand_init'].append({
                'core_h': h, 'gap': gap, 'engine': eng, 'status': s.verdict(),
                'semantic_eval': s.counters['semantic_eval'],
                'predicted': expected,
                'residual': s.counters['semantic_eval'] - expected,
                'initial_eval': s.counters.get('initial_eval'),
                'new_eval': s.counters.get('new_eval'),
                'note': 'first materialization subsumes that group\'s affected set'})
    for h, gap in ((0, 16), (256, 16)):
        ds = D.build_e2(h, gap, 1101, points_per_cell=2)
        for eng in ('B3-Eager', 'B3-Lazy'):
            cfg = {'dataset': 'synthetic_e2', 'route': 'synthetic_control',
                   'schedule': 'W2_final_only', 'engine': eng, 'core_h': h,
                   'gap': gap, 'seed': 1101, 'block': 0,
                   'run_dir': str(HERE / 'runs' / '_e2_counts')}
            s = SR.Session(cfg)
            s.run_synthetic(ds)
            out['two_points_per_cell'].append({
                'core_h': h, 'gap': gap, 'engine': eng, 'status': s.verdict(),
                'points_per_cell': 2, 'semantic_eval': s.counters['semantic_eval'],
                'predicted': s.counters.get('predicted_total'),
                'residual': s.counters.get('predicted_residual')})
    out['ok'] = (all(r['status'] == 'PASS' and r['residual'] == 0
                     for r in out['demand_init'] + out['two_points_per_cell']))
    return out


def timing(run_dir, blocks=30):
    records = []
    for h, gap in ENDPOINTS:
        for block in range(blocks):
            seed = SEEDS[block % len(SEEDS)]
            for eng in ('B3-Eager', 'B3-Lazy'):
                cfg = {'dataset': 'synthetic_e2', 'route': 'synthetic_control',
                       'schedule': 'W2_final_only', 'engine': eng, 'core_h': h,
                       'gap': gap, 'seed': seed, 'block': block,
                       'run_dir': str(run_dir / 'work' / ('e2_h%d_L%d_%s_b%02d' % (h, gap, eng, block)))}
                out = run_dir / 'sessions' / ('e2_h%d_L%d_%s_b%02d.json' % (h, gap, eng, block))
                out.parent.mkdir(parents=True, exist_ok=True)
                rec = R1.run_child(cfg, out)
                records.append(rec)
                print('  h=%d L=%d %s b=%02d %s %.3fs' % (h, gap, eng, block,
                      rec['status'], rec.get('spawn_wall_s', 0)), flush=True)
    return records


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--skip-counts', action='store_true')
    ap.add_argument('--skip-timing', action='store_true')
    ap.add_argument('--blocks', type=int, default=30)
    ap.add_argument('--quick', action='store_true')
    a = ap.parse_args()
    freeze = C.read_json(HERE / 'manifests' / 'freeze_g0.json')
    problems = FZ.verify(freeze)
    if problems:
        print(json.dumps({'FREEZE_FAIL': problems[:5]}))
        return 2
    config_hash = C.sha256_file(HERE / 'protocols' / 'matrix.json')
    run_dir = C.create_run_dir(HERE / 'runs', config_hash, 'e2')
    report = {'phase': 'E2', 'run_dir': str(run_dir.relative_to(PROJ).as_posix()),
              'protocol': 'protocols/R5_PROTOCOL.md'}
    prev_path = HERE / 'reports' / 'e2_report.json'
    if a.skip_counts and prev_path.is_file():
        prev = C.read_json(prev_path)
        for key in ('counts', 'ablation'):
            if key in prev:
                report[key] = prev[key]

    if not a.skip_counts:
        print('E2 phase A: counts')
        if a.quick:
            report['counts'] = counts(cores=[0], gaps=[16], seeds=[1101])
        else:
            report['counts'] = counts()
        print(json.dumps(report['counts']['summary'], indent=1))
        print('all correct:', report['counts']['all_correct'],
              'residuals:', report['counts']['max_abs_residual'])
        print('E2 phase C: ablations')
        report['ablation'] = ablation() if not a.quick else {'skipped': 'quick'}
        print('ablation ok:', report['ablation'].get('ok', 'skipped'))

    if not a.skip_timing:
        print('E2 phase B: timing (%d endpoints x %d blocks x 2 engines)'
              % (len(ENDPOINTS), a.blocks))
        recs = timing(run_dir, a.blocks)
        d = S.distribution(recs)
        report['timing'] = {'census': d['census'], 'n_valid': d['n_valid'],
                            'n_total': d['n_total'], 'paired': {}}
        for h, gap in ENDPOINTS:
            per = [r for r in recs if r['config']['core_h'] == h and r['config']['gap'] == gap]
            r = S.paired_ratios(per, 'B3-Lazy', 'B3-Eager')
            d2 = S.distribution(per)
            report['timing']['paired']['h%d_L%d' % (h, gap)] = {
                'n_valid': d2['n_valid'], 'census': d2['census'], 'ratio': r}
        C.write_json(run_dir / 'e2_timing.json', report['timing'])

    C.write_json(HERE / 'reports' / 'e2_report.json', report)
    C.write_json(run_dir / 'e2_report.json', report)
    print('wrote reports/e2_report.json')
    return 0


if __name__ == '__main__':
    sys.exit(main())
