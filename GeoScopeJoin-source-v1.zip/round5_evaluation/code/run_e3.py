"""E3: change-discovery contract and one-axis scale.

S-full discovers deltas by comparing complete before/after snapshots; S-log starts from
a verified baseline plus a complete delta event chain whose parsing and validation are
inside the timer. Offline log construction is reported separately (T_log_build).

One axis at a time (no Cartesian product). A single run per configuration is used for
cost explanation; this is not a latency ranking and no repetitions are claimed.
Large cases validate with the native reference for every row, plus a naive containment
scan on a deterministic sample.
"""
import json
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

import numpy as np

import r5_common as C
import reference_native as REF
import engines_r5 as E

NODATA = D_NOD = -200.0


def build(edge, n_points, n_regions, seed=20261110):
    rng = np.random.default_rng(seed)
    grid = C.grid_of(0.0, 0.0, edge)
    regions = C.regions_proportional(0.0, 0.0, edge, count=n_regions)
    # points on cells (with replacement when n_points exceeds the cell count)
    idx = rng.integers(0, edge * edge, size=n_points)
    points = {}
    for i, f in enumerate(idx):
        col, row = int(f % edge), int(f // edge)
        points['p%06d' % i] = (0.0, 0.0, col * 100.0 + 50.0, row * 100.0 + 50.0, 1)
    cells = {}
    for r in range(edge):
        for c in range(edge):
            cells[(c, edge - 1 - r)] = ('%d:%d' % (r, c), C.encode_units(1.0))
    return {'grid': grid, 'regions': regions, 'points': points, 'cells': cells, 'edge': edge}


def native_rows(case, cells, rv='r', pv='v', rh='rh', ph='ph'):
    arr = np.ones((case['edge'], case['edge']), dtype='float64')
    for (col, row), (_cid, val) in cells.items():
        arr[case['edge'] - 1 - row, col] = (float(val) / C.UNITS_SCALE
                                           if val is not None else NODATA)
    return REF.expected_rows(arr, NODATA, case['grid'], case['points'], case['regions'],
                             'units', rv, pv, rh, ph)


def run_case(edge, n_points, n_regions, frac, engine='B3-Lazy'):
    t_build0 = time.perf_counter()
    case = build(edge, n_points, n_regions)
    build_s = time.perf_counter() - t_build0
    # affected cells: those holding a target fraction of the points
    pids = sorted(case['points'])
    k = max(1, int(round(frac * len(pids)))) if frac > 0 else 0
    affected_pids = set(pids[:k])
    changed = sorted({(int((case['points'][p][2]) // 100), int((case['points'][p][3]) // 100))
                      for p in affected_pids}) if k else []
    new_cells = dict(case['cells'])
    for (col, row) in changed:
        new_cells[(col, row)] = ('%d:%d' % (edge - 1 - row, col), C.encode_units(2.0))

    t0 = time.perf_counter()
    eng = E.make(engine, case['points'], case['cells'], case['grid'], case['regions'])
    build_engine_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    eng.update(case['points'], case['points'], case['cells'], new_cells, changed, [])
    update_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    rows = eng.query('r', 'v', 'rh', 'ph')
    query_s = time.perf_counter() - t0
    total_s = build_s + build_engine_s + update_s + query_s
    t0 = time.perf_counter()
    exp, _ = native_rows(case, new_cells)
    oracle_s = time.perf_counter() - t0
    ok, diff = REF.verify(rows, exp)
    counters = eng.counters()
    counters.update(eng.state_bytes())
    eng.close()
    sample = sorted(case['points'])[:8]
    naive = REF.naive_cell_scan(new_cells, {p: case['points'][p] for p in sample},
                                case['grid'], case['regions'], 'r', 'v', 'rh', 'ph')
    naive_ok, _ = REF.verify(naive, [r for r in exp if r[1] in set(sample)])
    return {'cells_scanned': edge * edge, 'points': n_points, 'regions': n_regions,
            'affected_fraction_requested': frac,
            'changed_cells': len(changed), 'affected_points': k,
            'rows': len(rows), 'output_bytes': len(C.canonical_bytes(rows)),
            'semantic_eval': counters['semantic_eval'],
            'build_s': build_s, 'engine_build_s': build_engine_s,
            'update_s': update_s, 'query_s': query_s, 'total_s': total_s,
            'oracle_s': oracle_s, 'ok': ok, 'diff': diff,
            'naive_sample_ok': naive_ok,
            'state_bytes': counters.get('state_bytes'),
            'peak_rss': __import__('psutil').Process().memory_info().rss}


def delta_contract(edge=256, n_points=10000):
    """S-full vs S-log cost for the same change set."""
    case = build(edge, n_points, 3)
    pids = sorted(case['points'])[:max(1, n_points // 100)]
    changed = sorted({(int(case['points'][p][2] // 100), int(case['points'][p][3] // 100))
                      for p in pids})
    a = np.ones((edge, edge), dtype='float64')
    b = a.copy()
    for (col, row) in changed:
        b[edge - 1 - row, col] = 2.0
    t0 = time.perf_counter()
    diff_idx = np.argwhere(a != b)
    s_full = time.perf_counter() - t0
    log = [{'cell': [int(c), int(r)], 'before': 1.0, 'after': 2.0} for (c, r) in changed]
    payload = json.dumps(log).encode()
    t0 = time.perf_counter()
    parsed = json.loads(payload)
    validated = [(int(x['cell'][0]), int(x['cell'][1])) for x in parsed
                 if x['after'] != x['before']]
    s_log = time.perf_counter() - t0
    return {'changed_cells': len(changed), 'diff_entries': int(len(diff_idx)),
            's_full_s': s_full, 's_log_parse_validate_s': s_log,
            'log_bytes': len(payload),
            'equal_change_set': sorted(validated) == sorted(changed),
            'note': 'log build cost is offline and reported separately; the consumer '
                    'pays parsing and validation only in a producer-backed setting'}


def main():
    import freeze_closure as FZ
    freeze = C.read_json(HERE / 'manifests' / 'freeze_g0.json')
    problems = FZ.verify(freeze)
    if problems:
        print(json.dumps({'FREEZE_FAIL': problems[:5]}))
        return 2
    run_dir = C.create_run_dir(HERE / 'runs', C.sha256_file(HERE / 'protocols' / 'matrix.json'), 'e3')
    out = {'phase': 'E3', 'run_dir': str(run_dir.relative_to(PROJ).as_posix()),
           'design': 'one axis at a time; single run per configuration; no repetitions claimed',
           'cells_axis': [], 'points_axis': [], 'regions_axis': [],
           'affected_axis': [], 'delta_contract': None}

    print('E3 cells axis (N=1e4, G=3, affected=1%)')
    for edge in (256, 512, 1024):
        r = run_case(edge, 10000, 3, 0.01)
        out['cells_axis'].append(r)
        print('  edge=%d changed=%d eval=%d total=%.2fs ok=%s' % (edge, r['changed_cells'],
              r['semantic_eval'], r['total_s'], r['ok']), flush=True)

    print('E3 points axis (256^2, G=3, affected=1%)')
    for n in (1000, 10000, 100000):
        r = run_case(256, n, 3, 0.01)
        out['points_axis'].append(r)
        print('  points=%d eval=%d total=%.2fs ok=%s' % (n, r['semantic_eval'],
              r['total_s'], r['ok']), flush=True)

    print('E3 regions axis (256^2, N=1e4, affected=1%)')
    for g in (3, 30, 300):
        r = run_case(256, 10000, g, 0.01)
        out['regions_axis'].append(r)
        print('  regions=%d rows=%d total=%.2fs ok=%s' % (g, r['rows'], r['total_s'],
              r['ok']), flush=True)

    print('E3 affected-fraction axis (256^2, N=1e4, G=3)')
    for f in (0.0, 0.001, 0.01, 0.1, 1.0):
        r = run_case(256, 10000, 3, f)
        out['affected_axis'].append(r)
        print('  f=%.3f changed=%d eval=%d ok=%s' % (f, r['changed_cells'],
              r['semantic_eval'], r['ok']), flush=True)

    out['delta_contract'] = delta_contract()
    out['all_ok'] = all(r['ok'] and r['naive_sample_ok']
                        for key in ('cells_axis', 'points_axis', 'regions_axis', 'affected_axis')
                        for r in out[key])
    C.write_json(HERE / 'reports' / 'e3_report.json', out)
    C.write_json(run_dir / 'e3_report.json', out)
    print('wrote reports/e3_report.json all_ok=%s' % out['all_ok'])
    return 0 if out['all_ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
