"""E4: byte-budgeted cache, persistent 100-block trace, first-query cost.

M0 is calibrated on a fixture disjoint from the measured workload (the Shenzhen
registered snapshot), then frozen; budgets are 0.5 M0, 1 M0 and 2 M0. The byte-capped
cache either respects the budget or reports infeasible/fallback; the budget is never
silently enlarged. Every query passes the native reference.

The reported p50/p95 are per query inside one persistent session, so they carry
same-session correlation; this is stated, and p99 is not reported.
"""
import json
import pathlib
import statistics
import sys
import time

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

import numpy as np

import r5_common as C
import datasets_r5 as D
import engines_r5 as E
import reference_native as REF
import freeze_closure as FZ

BLOCKS = 100


def calibrate():
    """M0 from a controlled fixture disjoint from the measured layout (seed 9999).

    The calibration fixture has the same point count and grid as the measured
    workload but a different cell layout, so the budget is comparable rather than
    borrowed from an unrelated 148-point window.
    """
    cal_ds = D.build_e2(256, 16, 9999)
    eng = E.B3Lazy(cal_ds['points'], cal_ds['cells0'], cal_ds['grid'], cal_ds['regions'])
    eng.query('cal', 'cal', 'cal', 'cal')
    size = eng.state_bytes()
    eng.close()
    m0 = size['index_bytes']
    return {'fixture': 'controlled layout, seed 9999, 8192 points, 256x256 grid',
            'b3_lazy_index_bytes': m0,
            'index_bytes': size['index_bytes'], 'cache_bytes': size['cache_bytes']}


def run_budget(ds, budget, queries_note):
    """One persistent session: 100 event blocks, a query every layout gap."""
    points = ds['points']
    cells = dict(ds['cells0'])
    arr = np.ones((D.WIN, D.WIN), dtype='float64')
    for (col, row), (_cid, val) in cells.items():
        arr[D.WIN - 1 - row, col] = float(val) / C.UNITS_SCALE if val is not None else D.NODATA
    gap = ds['layout']['gap']
    eng = E.make('B2-byte', points, cells, ds['grid'], ds['regions'], budget_bytes=budget)
    lat, state_trace, checks = [], [], []
    oracle_s = 0.0
    total0 = time.perf_counter()
    for e in range(BLOCKS):
        ev = ds['events'][e % len(ds['events'])]
        value = 2 if e % 2 == 0 else 1
        for (col, row) in ev['changed_cells']:
            cells[(col, row)] = ('%d:%d' % (D.WIN - 1 - row, col), ev['value'])
            arr[D.WIN - 1 - row, col] = float(ev['value']) / C.UNITS_SCALE
        t = time.perf_counter()
        eng.update(points, points, cells, cells, ev['changed_cells'], [])
        state_trace.append({'block': e, 'phase': 'update',
                            'state_bytes': eng.state_bytes().get('state_bytes', 0)})
        if (e + 1) % gap == 0:
            t = time.perf_counter()
            rows = eng.query('r', 'v', 'rh', 'ph')
            lat.append(time.perf_counter() - t)
            to = time.perf_counter()
            exp, _ = REF.expected_rows(arr, D.NODATA, ds['grid'], points, ds['regions'],
                                       'units', 'r', 'v', 'rh', 'ph')
            oracle_s += time.perf_counter() - to
            ok, diff = REF.verify(rows, exp)
            checks.append({'block': e, 'ok': ok, 'rows': len(rows), 'diff': diff})
        state_trace.append({'block': e, 'phase': 'post',
                            'state_bytes': eng.state_bytes().get('state_bytes', 0)})
    total = time.perf_counter() - total0
    st = eng.state_bytes()
    eng.close()
    lat_sorted = sorted(lat)
    p50 = lat_sorted[int(0.5 * (len(lat_sorted) - 1))]
    p95 = lat_sorted[int(0.95 * (len(lat_sorted) - 1))]
    over = ([s['state_bytes'] for s in state_trace if s['state_bytes'] > budget]
            if not st.get('infeasible') else [])
    return {'budget_bytes': budget, 'queries': len(lat),
            'p50_query_s': p50, 'p95_query_s': p95,
            'mean_query_s': statistics.fmean(lat) if lat else None,
            'evictions': st.get('evictions'), 'bypass': st.get('bypass'),
            'infeasible': st.get('infeasible'),
            'fixed_index_over_budget': st.get('index_bytes', 0) > budget,
            'final_state_bytes': st.get('state_bytes'),
            'peak_state_bytes': max(s['state_bytes'] for s in state_trace),
            'budget_violations': len(over),
            'queries_ok': sum(1 for c in checks if c['ok']), 'queries_total': len(checks),
            'all_correct': all(c['ok'] for c in checks),
            'total_s': total, 'oracle_s': oracle_s,
            'note': queries_note}


def main():
    freeze = C.read_json(HERE / 'manifests' / 'freeze_g0.json')
    problems = FZ.verify(freeze)
    if problems:
        print(json.dumps({'FREEZE_FAIL': problems[:5]}))
        return 2
    run_dir = C.create_run_dir(HERE / 'runs', C.sha256_file(HERE / 'protocols' / 'matrix.json'), 'e4')
    cal = calibrate()
    M0 = cal['b3_lazy_index_bytes']
    ds = D.build_e2(256, 16, 1101)
    ds['layout']['gap'] = 16
    out = {'phase': 'E4', 'run_dir': str(run_dir.relative_to(PROJ).as_posix()),
           'calibration': cal, 'workload': {'layout': ds['layout'], 'blocks': BLOCKS,
                                            'events_source': '16-event controlled pattern, cycled'},
           'budgets': {}}
    for mult in (0.5, 1.0, 2.0):
        budget = int(M0 * mult)
        r = run_budget(ds, budget, 'per-query latency inside one persistent session; '
                                   'same-session correlation applies; p99 not reported')
        out['budgets']['%.1fM0' % mult] = r
        print('%.1fM0 budget=%d p50=%.4f p95=%.4f correct=%d/%d violations=%d'
              % (mult, budget, r['p50_query_s'], r['p95_query_s'], r['queries_ok'],
                 r['queries_total'], r['budget_violations']), flush=True)
    # reference: lazy maintenance without a cache budget
    s = {'cells': ds['cells0']}
    eng = E.B3Lazy(ds['points'], s['cells'], ds['grid'], ds['regions'])
    lat, ok_n, tot = [], 0, 0
    arr = np.ones((D.WIN, D.WIN), dtype='float64')
    for (col, row), (_cid, val) in ds['cells0'].items():
        arr[D.WIN - 1 - row, col] = float(val) / C.UNITS_SCALE if val is not None else D.NODATA
    cells = dict(ds['cells0'])
    for e in range(BLOCKS):
        ev = ds['events'][e % len(ds['events'])]
        value = 2 if e % 2 == 0 else 1
        for (col, row) in ev['changed_cells']:
            cells[(col, row)] = ('%d:%d' % (D.WIN - 1 - row, col), ev['value'])
            arr[D.WIN - 1 - row, col] = float(ev['value']) / C.UNITS_SCALE
        eng.update(ds['points'], ds['points'], cells, cells, ev['changed_cells'], [])
        if (e + 1) % 16 == 0:
            t = time.perf_counter()
            rows = eng.query('r', 'v', 'rh', 'ph')
            lat.append(time.perf_counter() - t)
            exp, _ = REF.expected_rows(arr, D.NODATA, ds['grid'], ds['points'],
                                       ds['regions'], 'units', 'r', 'v', 'rh', 'ph')
            ok, _ = REF.verify(rows, exp)
            tot += 1
            ok_n += 1 if ok else 0
    final_state = eng.state_bytes()
    eng.close()
    out['budgets']['no_budget_b3_lazy'] = {
        'queries': len(lat), 'p50_query_s': sorted(lat)[len(lat) // 2],
        'p95_query_s': sorted(lat)[int(0.95 * (len(lat) - 1))],
        'queries_ok': ok_n, 'queries_total': tot,
        'state_bytes': final_state,
        'note': 'reference maintenance cost without any cache budget'}
    C.write_json(HERE / 'reports' / 'e4_report.json', out)
    C.write_json(run_dir / 'e4_report.json', out)
    print('wrote reports/e4_report.json')
    return 0


if __name__ == '__main__':
    sys.exit(main())
