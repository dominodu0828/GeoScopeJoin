"""E5: real cross-cell move sampled from the native raster, version matrix, event guard.

Case construction
-----------------
Node 7639850987 v2 -> v3, coordinates taken from the recorded OSM history. Both
positions are located on the real R7_C29 E2020 tile; the window is the minimal native
rectangle covering both cells plus two cells of margin. Nothing is padded and no window
is reselected to force a numerical change.

If both releases cover the positions (they do), the full 2x2 request runs: raster
{R2022A, R2023A} x point {v2, v3}. Every state is compared against the native reference
for all four engines.

Event guard: strict version-chain acceptance; a rejected event leaves the snapshot
unchanged. These tests do not establish concurrency, serialization or crash recovery.
"""
import hashlib
import json
import math
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

import numpy as np

import r5_common as C
import reference_native as REF
import engines_r5 as E
import datasets_r5 as D

NODE = '7639850987'
HISTORY = PROJ / 'round3' / 'imd_locality' / 'experiments' / 'run_20261106_004925_2959818' / 'inputs' / ('node_%s_history.json' % NODE)
ZIPS = {'R2022A': PROJ / 'round2' / 'raster_revision' / 'inputs' / 'GHS_POP_E2020_R2022A_R7_C29.zip',
        'R2023A': PROJ / 'inputs' / 'R7_C29.zip'}
ANCHOR = (10857900.0, 2744600.0)


def node_positions():
    raw = HISTORY.read_bytes()
    doc = json.loads(raw)
    els = doc.get('elements', doc if isinstance(doc, list) else [])
    by_version = {}
    for e in els:
        if e.get('type') != 'node':
            continue
        if e.get('id') is not None and str(e['id']) != NODE:
            continue
        by_version[int(e['version'])] = (float(e['lon']), float(e['lat']), e.get('timestamp'))
    from pyproj import Transformer
    T = Transformer.from_crs('EPSG:4326', 'ESRI:54009', always_xy=True)
    out = {}
    for v, (lon, lat, ts) in by_version.items():
        x, y = T.transform(lon, lat)
        out[v] = {'lon': lon, 'lat': lat, 'x': x, 'y': y, 'timestamp': ts}
    return {'sha256': C.sha256_bytes(raw), 'versions': sorted(by_version),
            'positions': out, 'path': str(HISTORY.relative_to(PROJ).as_posix())}


def tile_cell(x, y, arr_meta):
    t = arr_meta['transform']
    col = int(math.floor((x - t[2]) / t[0]))
    row = int(math.floor((t[5] - y) / abs(t[4])))
    return col, row


def build_case():
    hist = node_positions()
    p2, p3 = hist['positions'][2], hist['positions'][3]
    arrs, metas = {}, {}
    for rel, zp in ZIPS.items():
        import rasterio
        with D.open_zip_tif(zp) as src:
            metas[rel] = {'crs': str(src.crs), 'transform': list(src.transform)[:6],
                          'width': src.width, 'height': src.height,
                          'nodata': float(src.nodata), 'member': D.zip_member(zp)}
        arrs[rel] = None  # read below once the window is known
    c2 = tile_cell(p2['x'], p2['y'], metas['R2023A'])
    c3 = tile_cell(p3['x'], p3['y'], metas['R2023A'])
    margin = 2
    r0 = min(c2[1], c3[1]) - margin
    r1 = max(c2[1], c3[1]) + margin
    c0 = min(c2[0], c3[0]) - margin
    c1 = max(c2[0], c3[0]) + margin
    h, w = r1 - r0 + 1, c1 - c0 + 1
    t = metas['R2023A']['transform']
    for rel, zp in ZIPS.items():
        import rasterio
        with D.open_zip_tif(zp) as src:
            if list(src.transform)[:6] != t:
                raise ValueError('release grids are not aligned for %s' % rel)
            arrs[rel] = src.read(1, window=((r0, r1 + 1), (c0, c1 + 1))).astype('float64')
    x0 = t[2] + c0 * t[0]
    y_top = t[5] - r0 * abs(t[4])
    y0 = y_top - h * abs(t[4])
    grid = C.grid_of(x0, y0, max(h, w), dx=float(t[0]), dy=float(abs(t[4])),
                     window_h=h, window_w=w)
    grid['crs'] = str(metas['R2023A']['crs'])
    pad = 200.0
    lo_x = min(p2['x'], p3['x']) - pad
    hi_x = max(p2['x'], p3['x']) + pad
    lo_y = min(p2['y'], p3['y']) - pad
    hi_y = max(p2['y'], p3['y']) + pad
    from shapely.geometry import box
    regions = {'both': box(lo_x, lo_y, hi_x, hi_y)}
    mid = (p2['x'] + p3['x']) / 2.0
    regions['old_only'] = box(lo_x, lo_y, mid, hi_y)
    regions['new_only'] = box(mid, lo_y, hi_x, hi_y)
    points = {'node:%s@v2' % NODE: (p2['lon'], p2['lat'], p2['x'], p2['y'], 2),
              'node:%s@v3' % NODE: (p3['lon'], p3['lat'], p3['x'], p3['y'], 3)}
    return {'hist': hist, 'grid': grid, 'regions': regions, 'points': points,
            'arrs': arrs, 'metas': metas, 'window': {'row0': r0, 'col0': c0, 'h': h, 'w': w},
            'cells': {'both': [c2, c3]}}


def _rows_state(case, raster, point_version):
    arr = case['arrs'][raster]
    pid = 'node:%s@v%d' % (NODE, point_version)
    pts = {pid: case['points'][pid]}
    grid = case['grid']
    nodata = case['metas'][raster]['nodata']
    rows, _lookup = REF.expected_rows(arr, nodata, grid, pts, case['regions'], 'units',
                                      raster, 'v%d' % point_version, 'zip-' + raster,
                                      'ph-node')
    return rows, pts


def run_matrix(case):
    results = []
    for raster in ('R2022A', 'R2023A'):
        for pv in (2, 3):
            exp, pts = _rows_state(case, raster, pv)
            cells = C.encode_array(case['arrs'][raster], case['metas'][raster]['nodata'], 'units')
            for eng_name in ('BFull-Fast', 'B3-Eager', 'B3-Lazy', 'B2-byte'):
                eng = E.make(eng_name, pts, cells, case['grid'], case['regions'],
                             **({'budget_bytes': 4 * 1024 * 1024} if eng_name == 'B2-byte' else {}))
                rows = eng.query(raster, 'v%d' % pv, 'zip-' + raster, 'ph-node')
                ok, diff = REF.verify(rows, exp)
                results.append({'raster': raster, 'point_version': pv, 'engine': eng_name,
                                'rows': len(rows), 'agree': ok, 'diff': diff,
                                'row_values': [r[2:5] for r in sorted(rows)][:4]})
                eng.close()
    return {'results': results, 'all_agree': all(r['agree'] for r in results)}


class EventGuard:
    """Strict version-chain guard for one stream.

    An event is accepted only when its base equals the current version, its sequence is
    contiguous and its before-digest matches the current snapshot digest. An identical
    committed event is acknowledged idempotently; the same id with a different payload
    is rejected. Rejection never mutates the snapshot.
    """

    def __init__(self, stream_id, version, digest):
        self.stream_id = stream_id
        self.version = version
        self.digest = digest
        self.seq = 0
        self.committed = {}
        self.log = []

    def submit(self, ev, payload_digest, apply_fn=None):
        eid = ev['event_id']
        if eid in self.committed:
            if self.committed[eid] == ev['payload_hash']:
                self.log.append((eid, 'DUPLICATE'))
                return 'DUPLICATE'
            self.log.append((eid, 'REJECT_ID_PAYLOAD_CONFLICT'))
            return 'REJECT_ID_PAYLOAD_CONFLICT'
        if ev['stream_id'] != self.stream_id:
            self.log.append((eid, 'REJECT_WRONG_STREAM'))
            return 'REJECT_WRONG_STREAM'
        if ev['sequence'] != self.seq + 1:
            self.log.append((eid, 'REJECT_SEQUENCE_GAP'))
            return 'REJECT_SEQUENCE_GAP'
        if ev['base_version'] != self.version:
            self.log.append((eid, 'REJECT_STALE_BASE'))
            return 'REJECT_STALE_BASE'
        if ev['before_digest'] != self.digest:
            self.log.append((eid, 'REJECT_DIGEST_MISMATCH'))
            return 'REJECT_DIGEST_MISMATCH'
        if ev['target_version'] <= ev['base_version']:
            self.log.append((eid, 'REJECT_NON_MONOTONE'))
            return 'REJECT_NON_MONOTONE'
        if apply_fn is not None:
            apply_fn(payload_digest)
        self.version = ev['target_version']
        self.digest = ev['after_digest']
        self.seq = ev['sequence']
        self.committed[eid] = ev['payload_hash']
        self.log.append((eid, 'APPLIED'))
        return 'APPLIED'


def _ev(eid, seq, base, target, before, after, payload):
    return {'event_id': eid, 'stream_id': 'node:%s' % NODE, 'sequence': seq,
            'base_version': base, 'target_version': target,
            'before_digest': before, 'after_digest': after, 'payload_hash': payload}


def event_guard_tests():
    d1, d2, d3, d4 = ('d%d' % i for i in range(1, 5))
    out = {}

    # ordered chain
    g = EventGuard('node:%s' % NODE, 1, d1)
    r = [g.submit(_ev('e1', 1, 1, 2, d1, d2, 'p1'), d2),
         g.submit(_ev('e2', 2, 2, 3, d2, d3, 'p2'), d3)]
    out['ordered_chain'] = {'results': r, 'version': g.version, 'digest': g.digest}

    # v2->v3 arriving first (base v2, current v1)
    g = EventGuard('node:%s' % NODE, 1, d1)
    r = g.submit(_ev('e2', 2, 2, 3, d2, d3, 'p2'), d3)
    out['late_base_first'] = {'result': r, 'version_unchanged': g.version == 1,
                             'digest_unchanged': g.digest == d1}

    # duplicate committed event, then same id with a different payload
    g = EventGuard('node:%s' % NODE, 1, d1)
    g.submit(_ev('e1', 1, 1, 2, d1, d2, 'p1'), d2)
    dup = g.submit(_ev('e1', 1, 1, 2, d1, d2, 'p1'), d2)
    conflict = g.submit(_ev('e1', 1, 1, 2, d1, d2, 'OTHER'), d2)
    out['duplicate'] = {'duplicate': dup, 'conflict': conflict,
                        'version_unchanged': g.version == 2}

    # stale update after delete
    g = EventGuard('node:%s' % NODE, 1, d1)
    g.submit(_ev('e1', 1, 1, 2, d1, d2, 'p1'), d2)
    g.submit(_ev('e2', 2, 2, 3, d2, 'DELETED', 'p2'), 'DELETED')
    stale = g.submit(_ev('e3', 3, 2, 4, d2, d4, 'p3'), d4)
    out['stale_after_delete'] = {'result': stale, 'version_unchanged': g.version == 3,
                                 'digest_unchanged': g.digest == 'DELETED'}

    # gap
    g = EventGuard('node:%s' % NODE, 1, d1)
    gap = g.submit(_ev('e5', 3, 1, 2, d1, d2, 'p5'), d2)
    out['sequence_gap'] = {'result': gap, 'version_unchanged': g.version == 1}

    # intermediate states are not coalesced: every accepted event is observable
    g = EventGuard('node:%s' % NODE, 1, d1)
    seen = []
    for i, dd in enumerate((d2, d3, d4), start=1):
        g.submit(_ev('s%d' % i, i, i, i + 1, 'd%d' % i, dd, 'p%d' % i), dd)
        seen.append(g.digest)
    out['intermediate_observable'] = {'digests': seen, 'all_distinct': len(set(seen)) == 3}

    out['ok'] = (out['ordered_chain']['results'] == ['APPLIED', 'APPLIED']
                 and out['late_base_first']['result'].startswith('REJECT')
                 and out['duplicate']['duplicate'] == 'DUPLICATE'
                 and out['duplicate']['conflict'].startswith('REJECT')
                 and out['stale_after_delete']['result'].startswith('REJECT')
                 and out['sequence_gap']['result'].startswith('REJECT')
                 and out['intermediate_observable']['all_distinct'])
    return out


def main():
    freeze = C.read_json(HERE / 'manifests' / 'freeze_g0.json')
    import freeze_closure as FZ
    problems = FZ.verify(freeze)
    if problems:
        print(json.dumps({'FREEZE_FAIL': problems[:5]}))
        return 2
    run_dir = C.create_run_dir(HERE / 'runs', C.sha256_file(HERE / 'protocols' / 'matrix.json'), 'e5')
    case = build_case()
    matrix = run_matrix(case)
    guard = event_guard_tests()
    report = {'phase': 'E5', 'run_dir': str(run_dir.relative_to(PROJ).as_posix()),
              'node': NODE, 'history': {k: v for k, v in case['hist'].items() if k != 'positions'},
              'positions': case['hist']['positions'],
              'window': case['window'], 'grid': case['grid'],
              'regions': list(case['regions']),
              'matrix': matrix, 'event_guard': guard}
    C.write_json(HERE / 'reports' / 'e5_report.json', report)
    C.write_json(run_dir / 'e5_report.json', report)
    print(json.dumps({'matrix_all_agree': matrix['all_agree'],
                      'guard_ok': guard['ok'],
                      'rows': [(r['raster'], r['point_version'], r['engine'], r['rows'])
                               for r in matrix['results'][:8]]}, indent=1))
    return 0 if matrix['all_agree'] and guard['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
