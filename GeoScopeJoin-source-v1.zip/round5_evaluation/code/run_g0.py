"""G0: real provenance, closure freeze, failure gate, native numeric reference.

Produces (all under round5_evaluation/):
  manifests/dataset_<name>.json   registered source/point/window records
  manifests/oracle_<name>.json    native-reference digests per state
  manifests/freeze_g0.json        execution closure + parameter binding
  reports/g0_report.json          gate results and evidence

No performance number is produced here.
"""
import copy
import json
import os
import pathlib
import platform
import shutil
import subprocess
import sys
import tempfile
import time

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

import numpy as np

import r5_common as C
import reference_native as REF
import datasets_r5 as D
import freeze_closure as FZ
import summarize as S


def environment():
    import numpy, shapely, rasterio, pyproj
    try:
        import psutil
        mem = psutil.virtual_memory().total
        cpu = psutil.cpu_count(logical=True)
    except Exception:
        mem, cpu = None, os.cpu_count()
    return {'python': sys.version, 'platform': platform.platform(),
            'processor': platform.processor(), 'cpu_logical': cpu, 'memory_bytes': mem,
            'libraries': {'numpy': numpy.__version__, 'shapely': shapely.__version__,
                          'rasterio': rasterio.__version__, 'pyproj': pyproj.__version__},
            'thread_env': {k: os.environ.get(k) for k in
                           ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')}}


def dataset_manifest(ds, name):
    m = ds['meta']
    states = []
    for i, s in enumerate(ds['states']):
        states.append({'rv': s['rv'], 'pv': s['pv'], 'rh': s['rh'], 'ph': s['ph'],
                       'link': [s['raster_index'], s['point_index']]})
    doc = {
        'schema': 'geoscopejoin-round5-dataset-v1',
        'dataset': name, 'window': m['window'], 'grid': m['grid'],
        'point_filter': m.get('point_filter', 'all'),
        'value_encoding': m['value_encoding'],
        'sources': m['sources'], 'point_sources': m['point_sources'],
        'states': states, 'events': m['events'],
        'regions_wkb_sha256': m['regions_wkb_sha256'],
        'regions_wkb': m['regions_wkb'],
    }
    return doc


def build_oracle(ds, name, sample=12):
    """Native-reference digests per state + a naive containment cross-check."""
    states = {}
    naive_checks = []
    for i, s in enumerate(ds['states']):
        rows, _ = REF.expected_rows(s['arr'], D.NODATA, ds['grid'], s['points'],
                                    ds['regions'], ds['encoding'],
                                    s['rv'], s['pv'], s['rh'], s['ph'])
        states[str(i)] = {'digest': C.rows_digest(rows), 'rows': len(rows),
                          'status_counts': {st: sum(1 for r in rows if r[3] == st)
                                            for st in ('OBSERVED', 'NODATA', 'NO_COVERAGE')},
                          'semantic_digest': C.rows_digest(REF.semantic_prefix(rows))}
        if i == 0:
            pids = sorted(s['points'])[:sample]
            sub = {p: s['points'][p] for p in pids}
            naive = REF.naive_cell_scan(s['cells'], sub, ds['grid'], ds['regions'],
                                        s['rv'], s['pv'], s['rh'], s['ph'])
            exp_sub = [r for r in rows if r[1] in set(pids)]
            ok, diff = REF.verify(naive, exp_sub)
            naive_checks.append({'dataset': name, 'state': i, 'points': len(pids),
                                 'agree': ok, 'diff': diff,
                                 'cells_scanned': len(s['cells'])})
    return {'schema': 'geoscopejoin-round5-oracle-v1', 'dataset': name,
            'reference': 'native array + validity mask + source transform; '
                         'no candidate encoder, affected set or reverse index',
            'encoding': ds['encoding'], 'states': states,
            'naive_cross_check': naive_checks}


def provenance_gate(run_dir):
    """Source-only change: same values, different registered bytes."""
    import io
    import zipfile
    import rasterio
    from rasterio.io import MemoryFile
    from rasterio.transform import from_origin

    arr = np.arange(256, dtype='float64').reshape(16, 16) + 0.5
    with MemoryFile() as mem:
        with mem.open(driver='GTiff', width=16, height=16, count=1, dtype='float64',
                      crs='ESRI:54009', transform=from_origin(0, 1600, 100, 100),
                      nodata=-200.0) as ds:
            ds.write(arr, 1)
        tif = mem.read()
    fdir = pathlib.Path(run_dir) / 'fixtures'
    fdir.mkdir(parents=True, exist_ok=True)
    zips = []
    for tag, date in (('a', (2026, 1, 1, 0, 0, 0)), ('b', (2026, 1, 2, 0, 0, 0))):
        z = fdir / ('source_only_%s.zip' % tag)
        with zipfile.ZipFile(z, 'w', zipfile.ZIP_STORED) as zf:
            info = zipfile.ZipInfo('window.tif', date_time=date)
            zf.writestr(info, tif)
        zips.append(z)
    hashes = [C.sha256_file(z) for z in zips]
    dec = [D.decode_zip_window(z, 0, 0, 16)[0] for z in zips]
    same_values = bool(np.array_equal(dec[0], dec[1]))

    grid = C.grid_of(0.0, 0.0, 16)
    regions = {'whole': __import__('shapely.geometry', fromlist=['box']).box(0, 0, 1600, 1600)}
    pts = {'p1': (0.0, 0.0, 50.0, 1550.0, 1)}
    rows_a, _ = REF.expected_rows(dec[0], -200.0, grid, pts, regions, 'units',
                                  'R-test', 'snapshot:x', hashes[0], 'ph-test')
    rows_b, _ = REF.expected_rows(dec[1], -200.0, grid, pts, regions, 'units',
                                  'R-test', 'snapshot:x', hashes[1], 'ph-test')
    same_semantics = REF.semantic_prefix(rows_a) == REF.semantic_prefix(rows_b)
    different_suffix = (rows_a[0][7] != rows_b[0][7])
    # a stale-hash emitter must be caught by the checker
    stale = [r[:7] + (hashes[0], r[8]) for r in rows_b]
    caught_ok, _ = REF.verify(stale, rows_b)
    return {'bytes_differ': hashes[0] != hashes[1],
            'values_identical': same_values,
            'semantic_prefix_identical': same_semantics,
            'source_suffix_differs': different_suffix,
            'stale_hash_detected': not caught_ok,
            'ok': all([hashes[0] != hashes[1], same_values, same_semantics,
                       different_suffix, not caught_ok]),
            'fixture_zips': [str(z.relative_to(PROJ).as_posix()) for z in zips]}


def numeric_gate():
    contract = REF.check_numeric_contract()
    scale = REF.check_scale_offset()
    wording = REF.check_units_denominator_wording()
    ok = contract['all_ok'] and scale['ok'] and wording['mentions_denominator']
    return {'contract': contract, 'scale_offset': scale, 'wording': wording, 'ok': ok}


def negative_controls(freeze_doc, targets):
    """One-byte edits to copies of the recorded targets must each be rejected."""
    results = []
    tmp = pathlib.Path(tempfile.mkdtemp(prefix='r5neg_'))
    try:
        for label, rel in targets:
            src = PROJ / rel
            if not src.is_file():
                results.append({'target': label, 'path': rel, 'rejected': None,
                                'note': 'not present'})
                continue
            dst = tmp / (label + pathlib.Path(rel).suffix)
            shutil.copy2(src, dst)
            b = bytearray(dst.read_bytes())
            idx = len(b) // 2
            b[idx] = b[idx] ^ 0x01
            dst.write_bytes(bytes(b))
            problems = FZ.verify(freeze_doc, overrides={rel: str(dst)})
            results.append({'target': label, 'path': rel,
                            'rejected': any('hash mismatch' in p for p in problems),
                            'problems': problems[:2]})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return {'ok': all(r['rejected'] for r in results if r['rejected'] is not None),
            'results': results}


def main():
    t0 = time.perf_counter()
    config_hash = C.sha256_file(HERE / 'protocols' / 'matrix.json')
    run_dir = C.create_run_dir(HERE / 'runs', config_hash, 'g0')
    report = {'phase': 'G0', 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'run_dir': str(run_dir.relative_to(PROJ).as_posix()),
              'environment': environment()}

    print('- building datasets')
    sz = D.build_shenzhen()
    sp = D.build_sao_paulo()
    datasets = {'shenzhen_same_epoch_release_pair': sz, 'sao_paulo_cross_epoch_published_grids': sp}
    report['datasets'] = {}
    for name, ds in datasets.items():
        man = dataset_manifest(ds, name)
        C.write_json(HERE / 'manifests' / ('dataset_%s.json' % name), man)
        oracle = build_oracle(ds, name)
        C.write_json(HERE / 'manifests' / ('oracle_%s.json' % name), oracle)
        report['datasets'][name] = {
            'points_per_state': [len(s['points']) for s in ds['states']],
            'rows_per_state': [oracle['states'][str(i)]['rows'] for i in range(len(ds['states']))],
            'status_counts': [oracle['states'][str(i)]['status_counts'] for i in range(len(ds['states']))],
            'events': [e['cells'] for e in ds['events']],
            'encoding': ds['encoding'],
            'npy_matches_decode': [s.get('npy_matches_decode') for s in ds['meta']['sources']],
            'naive_cross_check': oracle['naive_cross_check'],
            'region_hash': ds['meta']['regions_wkb_sha256'],
        }
        print('  %-42s states=%d rows=%s enc=%s' % (name, len(ds['states']),
              [oracle['states'][str(i)]['rows'] for i in range(len(ds['states']))], ds['encoding']))

    print('- provenance gate')
    report['provenance'] = provenance_gate(run_dir)
    print('- numeric gate')
    report['numeric'] = numeric_gate()
    print('- failure gate self-test')
    report['failure_gate'] = S.gate_selftest()

    print('- discovery pass')
    disc = FZ.discover_runtime()
    report['discovery'] = {'modules': len(disc['modules']), 'opened': len(disc['opened']),
                           'third_party': disc['third_party']}
    files = FZ.declared_project_files()
    for m in disc['modules'].values():
        files.add(pathlib.Path(m))
    for p in disc['opened']:
        files.add(pathlib.Path(p))
    # registered inputs referenced by the manifests
    for name in datasets:
        man = C.read_json(HERE / 'manifests' / ('dataset_%s.json' % name))
        for s in man['sources']:
            files.add(PROJ / s['zip_path'])
            files.add(PROJ / s['registered_npy']) if s.get('registered_npy') else None
        for p in man['point_sources']:
            files.add(PROJ / p['path'])
    # a freeze cannot contain its own hash
    files = {f for f in files if pathlib.Path(f).name != 'freeze_g0.json'}
    matrix = C.read_json(HERE / 'protocols' / 'matrix.json')
    params = {'E1': matrix['E1'], 'E2': matrix['E2'], 'E4': matrix['E4'],
              'E5': matrix['E5'], 'E3': matrix['E3'], 'resources': matrix['resources']}
    freeze = FZ.build(files, params, extra={'protocol_sha256':
                                            C.sha256_file(HERE / 'protocols' / 'R5_PROTOCOL.md')})
    problems = FZ.verify(freeze)
    report['freeze'] = {'files': len(freeze['files']), 'problems': problems,
                        'params_sha256': freeze['params_sha256'][:16]}
    C.write_json(HERE / 'manifests' / 'freeze_g0.json', freeze)
    print('  closure files: %d, problems: %d' % (len(freeze['files']), len(problems)))

    print('- negative controls')
    pick = []
    code_rel = 'round5_evaluation/code/engines_r5.py'
    pick.append(('direct_source', code_rel))
    pick.append(('round2_dependency', 'round2/raster_revision/inputs/r2023_window.npy'))
    pick.append(('oracle', 'round5_evaluation/manifests/oracle_shenzhen_same_epoch_release_pair.json'))
    pick.append(('protocol', 'round5_evaluation/protocols/R5_PROTOCOL.md'))
    pick.append(('input_manifest', 'round5_evaluation/manifests/dataset_shenzhen_same_epoch_release_pair.json'))
    pick.append(('matrix', 'round5_evaluation/protocols/matrix.json'))
    pick.append(('point_source', 'round3/imd_locality/inputs/holdout_osm_2023-10-14.json'))
    report['negative_controls'] = negative_controls(freeze, pick)
    report['negative_controls']['note'] = (
        'each target is a copy with one flipped byte; the verifier must reject it. '
        'round5 does not import round2 modules, so its transitive dependency is the '
        'registered round2 NPY window, which the closure covers as an input.')

    report['params_match_selftest'] = {
        'accepts_valid': FZ.parameters_match(
            {'dataset': 'shenzhen_same_epoch_release_pair', 'route': 'raw_service',
             'schedule': 'W2_final_only', 'engine': 'B3-Eager', 'block': 3, 'H': 1}, matrix) == [],
        'rejects_bad_block': bool(FZ.parameters_match(
            {'dataset': 'shenzhen_same_epoch_release_pair', 'route': 'raw_service',
             'schedule': 'W2_final_only', 'engine': 'B3-Eager', 'block': 999, 'H': 1}, matrix)),
        'rejects_bad_H': bool(FZ.parameters_match(
            {'dataset': 'shenzhen_same_epoch_release_pair', 'route': 'registered_service',
             'schedule': 'W2_final_only', 'engine': 'B3-Eager', 'block': 1, 'H': 7}, matrix)),
    }

    gates = {
        'provenance': report['provenance']['ok'],
        'numeric': report['numeric']['ok'],
        'failure_gate': report['failure_gate']['ok'],
        'freeze': len(problems) == 0,
        'negative_controls': report['negative_controls']['ok'],
        'params_binding': all(report['params_match_selftest'].values()),
        'npy_independent_check': all(
            all((s.get('npy_matches_decode') is True) for s in datasets[n]['meta']['sources'])
            for n in ('shenzhen_same_epoch_release_pair',)),
        'naive_cross_check': all(c['agree'] for n in datasets
                                 for c in report['datasets'][n]['naive_cross_check']),
    }
    report['gates'] = gates
    report['all_gates_pass'] = all(gates.values())
    report['wall_s'] = round(time.perf_counter() - t0, 2)
    C.write_json(HERE / 'reports' / 'g0_report.json', report)
    print(json.dumps(gates, indent=1))
    print('all gates pass:', report['all_gates_pass'], 'wall_s', report['wall_s'])
    return 0 if report['all_gates_pass'] else 1


if __name__ == '__main__':
    sys.exit(main())
