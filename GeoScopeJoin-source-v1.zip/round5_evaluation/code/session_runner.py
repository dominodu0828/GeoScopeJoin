"""One Round 5 session, executed in its own process.

Routes
------
raw_service         : ZIP -> window -> encode -> points -> diff -> engine -> query
registered_service  : ZIP -> immutable NPY snapshot (T_register) -> per-request
                      identity check -> engine -> query
synthetic_control   : controlled matrix (E2), in-memory, native reference built
                      from the generator's own state record

The lifecycle timer is one outer wall; phases are mutually exclusive. Correctness
comparison happens after `close` and is recorded as experiment overhead, never
inside the service total. Any mismatch is stored with the session record.

Usage: python -I session_runner.py --config C.json --out R.json
"""
import argparse
import hashlib
import json
import math
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code'), str(PROJ / '.deps')]

import numpy as np

import r5_common as C
import reference_native as REF
import engines_r5 as E
import datasets_r5 as D

RSS_LIMIT = 4 * 1024 ** 3


def _rss():
    try:
        import psutil
        mi = psutil.Process().memory_info()
        return {'rss': mi.rss, 'peak_rss': getattr(mi, 'peak_wset', None)}
    except Exception:
        return {'rss': None, 'peak_rss': None}


def _sink(rows):
    """Canonical bytes -> hash sink; returns (digest, bytes) without disk I/O."""
    b = C.canonical_bytes(rows)
    return hashlib.sha256(b).hexdigest(), len(b)


class Session:
    def __init__(self, cfg):
        self.cfg = cfg
        self.problems = []
        self.source_ok = True
        self.checks = []
        self.timers = {}
        self.counters = {}
        self.out_bytes = 0
        self.digests = []

    # ---------------------------------------------------------------- helpers
    def _fail_source(self, msg):
        self.source_ok = False
        self.problems.append(msg)

    def _query(self, eng, timer, state_idx, rv, pv, rh, ph, expected, nested=False):
        phase_ctx = timer.subphase if nested else timer.phase
        with phase_ctx('query'):
            rows = eng.query(rv, pv, rh, ph)
        with phase_ctx('serialize'):
            digest, nbytes = _sink(rows)
            self.out_bytes += nbytes
            exp = expected.get(str(state_idx))
            ok = bool(exp and exp['digest'] == digest and exp['rows'] == len(rows))
            self.checks.append({'state': state_idx, 'ok': ok, 'rows': len(rows),
                                'bytes': nbytes, 'digest': digest,
                                'expected_rows': exp['rows'] if exp else None})
            self.digests.append(digest)
        return ok

    # ------------------------------------------------------------------ E1 raw
    def run_raw(self, plan, oracle, budget_bytes=None):
        timer = C.PhaseTimer()
        with timer.phase('source_verify'):
            for z in plan['zips']:
                got = C.sha256_file(z['path'])
                if got != z['zip_sha256']:
                    self._fail_source('zip hash mismatch %s' % z['path'])
        with timer.phase('decode'):
            arrs = [D.decode_zip_window(z['path'], plan['window']['row0'],
                                        plan['window']['col0'], plan['window']['size'])[0]
                    for z in plan['zips']]
        with timer.phase('decode_verify'):
            for arr, z in zip(arrs, plan['zips']):
                if C.sha256_npy(arr) != z['window_sha256_npy']:
                    self._fail_source('decoded window hash mismatch %s' % z['path'])
        with timer.phase('encode'):
            cells = [C.encode_array(a, D.NODATA, plan['encoding']) for a in arrs]
        with timer.phase('point_prepare'):
            point_sets = []
            for pf in plan['point_files']:
                pts, info = D.load_osm(pf['path'])
                if info['sha256'] != pf['sha256']:
                    self._fail_source('point hash mismatch %s' % pf['path'])
                if plan.get('point_filter') == 'inside_window':
                    pts = {pid: p for pid, p in pts.items()
                           if REF._row_col(p[2], p[3], plan['grid'])[2]}
                point_sets.append(pts)
        with timer.phase('diff'):
            events = _deltas(plan['state_links'], cells, point_sets)
        grid = plan['grid']
        from shapely import wkb
        regions = {gid: wkb.loads(bytes.fromhex(h)) for gid, h in plan['regions_wkb'].items()}
        if C.regions_wkb_sha(regions) != plan['regions_wkb_sha256']:
            self._fail_source('region layout hash mismatch')
        s0 = plan['state_links'][0]
        with timer.phase('build'):
            eng = E.make(self.cfg['engine'], point_sets[s0[1]], cells[s0[0]], grid,
                         regions, **({'budget_bytes': budget_bytes} if budget_bytes else {}))
        expected = oracle['states']
        sched = self.cfg['schedule']
        # One top-level replay phase; update/query/serialize are nested components, so
        # loop bookkeeping and collection pauses cannot leak into an unaccounted gap.
        with timer.phase('replay'):
            if sched == 'W3_each_state':
                self._query(eng, timer, 0, *plan['provenance'][0], expected, nested=True)
            cur_state = s0
            for i, ev in enumerate(events, start=1):
                nxt = plan['state_links'][i]
                with timer.subphase('update'):
                    eng.update(point_sets[cur_state[1]], point_sets[nxt[1]],
                               cells[cur_state[0]], cells[nxt[0]],
                               ev['changed_cells'], ev['changed_pids'])
                cur_state = nxt
                if sched == 'W3_each_state':
                    self._query(eng, timer, i, *plan['provenance'][i], expected, nested=True)
            if sched == 'W2_final_only':
                self._query(eng, timer, len(plan['state_links']) - 1,
                            *plan['provenance'][-1], expected, nested=True)
            with timer.subphase('close'):
                eng.close()
        self.timers['lifecycle'] = timer.closure()
        self.counters = eng.counters()
        self.counters.update(eng.state_bytes())
        self.timers['oracle_check'] = 0.0

    # ---------------------------------------------------------- E1 registered
    def run_registered(self, plan, oracle, replay_H=1):
        reg = C.PhaseTimer()
        with reg.phase('register_decode'):
            arrs = [D.decode_zip_window(z['path'], plan['window']['row0'],
                                        plan['window']['col0'], plan['window']['size'])[0]
                    for z in plan['zips']]
        with reg.phase('register_verify'):
            for arr, z in zip(arrs, plan['zips']):
                if C.sha256_npy(arr) != z['window_sha256_npy']:
                    self._fail_source('decoded window hash mismatch %s' % z['path'])
        with reg.phase('register_snapshot'):
            snaps = []
            for i, arr in enumerate(arrs):
                p = pathlib.Path(self.cfg['run_dir']) / 'registered'
                p.mkdir(parents=True, exist_ok=True)
                f = p / ('state%d.npy' % i)
                np.save(f, arr, allow_pickle=False)
                snaps.append({'path': str(f), 'sha256': C.sha256_file(f),
                              'bytes': f.stat().st_size})
        with reg.phase('register_encode'):
            cells = [C.encode_array(a, D.NODATA, plan['encoding']) for a in arrs]
        with reg.phase('register_points'):
            point_sets = []
            for pf in plan['point_files']:
                pts, info = D.load_osm(pf['path'])
                if info['sha256'] != pf['sha256']:
                    self._fail_source('point hash mismatch %s' % pf['path'])
                if plan.get('point_filter') == 'inside_window':
                    pts = {pid: p for pid, p in pts.items()
                           if REF._row_col(p[2], p[3], plan['grid'])[2]}
                point_sets.append(pts)
        with reg.phase('register_diff'):
            events = _deltas(plan['state_links'], cells, point_sets)
        self.timers['register'] = reg.closure()

        grid = plan['grid']
        from shapely import wkb
        regions = {gid: wkb.loads(bytes.fromhex(h)) for gid, h in plan['regions_wkb'].items()}
        expected = oracle['states']
        online_total = 0.0
        agg = {'phases': {}, 'sum_s': 0.0}
        for h in range(replay_H):
            timer = C.PhaseTimer()
            with timer.phase('online'):
                with timer.subphase('verify_snapshot'):
                    for s in snaps:
                        if C.sha256_file(s['path']) != s['sha256']:
                            self._fail_source('snapshot identity changed %s' % s['path'])
                    if C.regions_wkb_sha(regions) != plan['regions_wkb_sha256']:
                        self._fail_source('region layout changed')
                    if [list(p) for p in plan['provenance']] != plan['provenance_check']:
                        self._fail_source('version chain changed')
                s0 = plan['state_links'][0]
                with timer.subphase('build'):
                    eng = E.make(self.cfg['engine'], point_sets[s0[1]], cells[s0[0]],
                                 grid, regions)
                sched = self.cfg['schedule']
                if sched == 'W3_each_state':
                    self._query(eng, timer, 0, *plan['provenance'][0], expected, nested=True)
                cur = s0
                for i, ev in enumerate(events, start=1):
                    nxt = plan['state_links'][i]
                    with timer.subphase('update'):
                        eng.update(point_sets[cur[1]], point_sets[nxt[1]],
                                   cells[cur[0]], cells[nxt[0]],
                                   ev['changed_cells'], ev['changed_pids'])
                    cur = nxt
                    if sched == 'W3_each_state':
                        self._query(eng, timer, i, *plan['provenance'][i], expected,
                                    nested=True)
                if sched == 'W2_final_only':
                    self._query(eng, timer, len(plan['state_links']) - 1,
                                *plan['provenance'][-1], expected, nested=True)
                with timer.subphase('close'):
                    eng.close()
            online_total += timer.total()
            # per-replay diagnostics are kept for inspection but are not the measured
            # unit when H > 1; the gating unit is the aggregate online total below.
            self.timers['online_diag_%d' % h] = {k: v for k, v in timer.closure().items()
                                                  if k in ('total_s', 'phases_s')}
            for name, secs in timer.phases.items():
                agg['phases'][name] = agg['phases'].get(name, 0.0) + secs
            agg['sum_s'] += sum(timer.phases.values())
            self.counters = eng.counters()
            self.counters.update(eng.state_bytes())
        self.timers['online_total_s'] = online_total
        self.timers['online_total'] = {
            'total_s': online_total, 'phase_sum_s': agg['sum_s'],
            'residual_s': online_total - agg['sum_s'],
            'residual_fraction': (abs(online_total - agg['sum_s']) / online_total
                                  if online_total else 0.0),
            'phases_s': dict(agg['phases']), 'subphases_s': {},
            'replays': replay_H}

    # ------------------------------------------------------------ E2 synthetic
    def run_synthetic(self, ds):
        """Replay the controlled matrix; expected rows are built on demand.

        The native array is advanced in place with the same event values, so every
        queried state is checked against a reference derived from native data rather
        than from the engine.
        """
        points = ds['points']
        cells = dict(ds['cells0'])
        arr = np.ones((D.WIN, D.WIN), dtype='float64')
        for (col, row), (_cid, val) in cells.items():
            arr[D.WIN - 1 - row, col] = (float(val) / C.UNITS_SCALE
                                         if val is not None else D.NODATA)
        expected, oracle_s = {}, 0.0

        def ensure_expected(idx):
            nonlocal oracle_s
            key = str(idx)
            if key in expected:
                return
            t0 = time.perf_counter()
            rows, _ = REF.expected_rows(arr, D.NODATA, ds['grid'], points, ds['regions'],
                                        'units', 'synthetic', 'synthetic', 'synthetic',
                                        'synthetic')
            oracle_s += time.perf_counter() - t0
            expected[key] = {'digest': C.rows_digest(rows), 'rows': len(rows)}

        timer = C.PhaseTimer()
        with timer.phase('build'):
            eng = E.make(self.cfg['engine'], points, cells, ds['grid'], ds['regions'])
        gap = ds['layout']['gap']
        nq = 0
        # One top-level replay phase; update/query/serialize are nested components.
        with timer.phase('replay'):
            for i, ev in enumerate(ds['events'], start=1):
                with timer.subphase('update'):
                    for key in ev['changed_cells']:
                        col, row = key
                        cells[key] = ('%d:%d' % (D.WIN - 1 - row, col), ev['value'])
                        arr[D.WIN - 1 - row, col] = float(ev['value']) / C.UNITS_SCALE
                    eng.update(points, points, cells, cells, ev['changed_cells'], [])
                due = (i % gap == 0) or (i == len(ds['events']))
                if due:
                    ensure_expected(i)
                    self._query(eng, timer, i, 'synthetic', 'synthetic',
                                'synthetic', 'synthetic', expected, nested=True)
                    nq += 1
        with timer.phase('close'):
            eng.close()
        self.timers['lifecycle'] = timer.closure()
        self.timers['oracle_build'] = {'total_s': oracle_s,
                                       'states': sorted(int(k) for k in expected)}
        self.counters = eng.counters()
        self.counters.update(eng.state_bytes())
        self.counters['queries'] = nq
        self.counters['predicted'] = ds['predicted']
        which = {'B3-Eager': 'C_E', 'B3-Lazy': 'C_L',
                 'B3-Lazy-demand-init': 'C_L'}.get(self.cfg['engine'])
        if which:
            self.counters['predicted_total'] = ds['predicted'][which]
            self.counters['predicted_residual'] = (self.counters['semantic_eval']
                                                   - ds['predicted'][which])

    # ---------------------------------------------------------------- verdict
    def verdict(self, closure_max=0.01):
        timing_ok = True
        gate_names = ('lifecycle', 'register', 'online_total')
        for k in gate_names:
            v = self.timers.get(k)
            if isinstance(v, dict) and 'residual_fraction' in v:
                if v['residual_fraction'] > closure_max:
                    timing_ok = False
                    self.problems.append('phase closure %.4f > %.4f in %s'
                                         % (v['residual_fraction'], closure_max, k))
        rss = _rss()
        resource_ok = rss.get('rss') is None or rss['rss'] <= RSS_LIMIT
        correctness_ok = all(c['ok'] for c in self.checks) and bool(self.checks)
        if not correctness_ok:
            bad = [c for c in self.checks if not c['ok']][:1]
            self.problems.append('query mismatch: %r' % (bad,))
        if not self.source_ok:
            status = 'SOURCE_FAIL'
        elif not correctness_ok:
            status = 'CORRECTNESS_FAIL'
        elif not resource_ok:
            status = 'RESOURCE_LIMIT'
        elif not timing_ok:
            status = 'TIMING_INVALID'
        else:
            status = 'PASS'
        return status


def _deltas(state_links, cells, point_sets):
    """Complete identifier-level deltas between consecutive states."""
    out = []
    for (r0, p0), (r1, p1) in zip(state_links, state_links[1:]):
        a, b = cells[r0], cells[r1]
        changed = sorted(k for k in a.keys() | b.keys() if a.get(k) != b.get(k))
        pa, pb = point_sets[p0], point_sets[p1]
        pids = sorted(set(pa) ^ set(pb) |
                      {p for p in set(pa) & set(pb) if pa[p][2:4] != pb[p][2:4]})
        out.append({'changed_cells': changed, 'changed_pids': pids})
    return out


def plan_from_manifest(ds_name):
    """Frozen execution plan (no decoding; provenance comes from the manifest)."""
    manifest = C.read_json(HERE / 'manifests' / ('dataset_%s.json' % ds_name))
    grid = manifest['grid']
    regions_wkb = dict(manifest['regions_wkb'])
    plan = {
        'window': manifest['window'], 'grid': grid,
        'encoding': manifest['value_encoding'],
        'zips': [{'path': str((PROJ / s['zip_path']).resolve()),
                  'zip_sha256': s['zip_sha256'],
                  'window_sha256_npy': s['window_sha256_npy']} for s in manifest['sources']],
        'point_files': [{'path': str((PROJ / p['path']).resolve()), 'sha256': p['sha256']}
                        for p in manifest['point_sources']],
        'state_links': [tuple(s['link']) for s in manifest['states']],
        'provenance': [(s['rv'], s['pv'], s['rh'], s['ph']) for s in manifest['states']],
        'regions_wkb': regions_wkb,
        'regions_wkb_sha256': manifest['regions_wkb_sha256'],
        'dataset': ds_name, 'point_filter': manifest.get('point_filter', 'all'),
    }
    plan['provenance_check'] = [list(p) for p in plan['provenance']]
    return plan


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    cfg = C.read_json(a.config)
    s = Session(cfg)
    t_wall = time.perf_counter()
    result = {'config': cfg}
    try:
        if cfg['dataset'] == 'synthetic_e2':
            ds = D.build_e2(cfg['core_h'], cfg['gap'], cfg['seed'])
            s.run_synthetic(ds)
            result['predicted'] = ds['predicted']
        else:
            plan = plan_from_manifest(cfg['dataset'])
            oracle = C.read_json(HERE / 'manifests' / ('oracle_%s.json' % cfg['dataset']))
            budget = cfg.get('budget_bytes')
            if cfg['route'] == 'raw_service':
                s.run_raw(plan, oracle, budget)
            elif cfg['route'] == 'registered_service':
                s.run_registered(plan, oracle, cfg.get('H', 1))
            else:
                raise ValueError('unknown route %r' % cfg['route'])
            result['dataset_manifest_sha256'] = C.sha256_file(
                HERE / 'manifests' / ('dataset_%s.json' % cfg['dataset']))
        status = s.verdict()
    except MemoryError:
        status = 'RESOURCE_LIMIT'
        s.problems.append('MemoryError')
    except Exception as exc:  # crash is a first-class status, never a dropped sample
        import traceback
        status = 'CRASH'
        s.problems.append('%s: %s' % (type(exc).__name__, exc))
        traceback.print_exc()
    result.update({
        'status': status, 'problems': s.problems,
        'timers': s.timers, 'counters': s.counters,
        'query_checks': s.checks, 'output_bytes': s.out_bytes,
        'resources': _rss(), 'wall_s': time.perf_counter() - t_wall,
        'checks_ok': sum(1 for c in s.checks if c['ok']),
        'checks_total': len(s.checks),
    })
    C.write_json(a.out, result)
    print(json.dumps({'status': status, 'checks': '%d/%d' % (result['checks_ok'], result['checks_total']),
                      'wall_s': round(result['wall_s'], 3),
                      'problems': s.problems[:2]}))
    return 0 if status == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
