"""Session gating, paired statistics and claim status (G0.3 / §9).

A session enters a performance distribution only when every gate passes. Failures are
counted and reported, never dropped silently.
"""
import json
import pathlib
import random
import statistics
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
sys.path[:0] = [str(HERE / 'code')]

import r5_common as C

CLOSURE_MAX = 0.01


def service_total(rec):
    t = rec.get('timers') or {}
    if 'lifecycle' in t:
        return t['lifecycle']['total_s']
    if 'register' in t:
        return t['register']['total_s'] + t.get('online_total_s', 0.0)
    return None


def validity(rec):
    """(valid, status, reasons) for one session record."""
    reasons = []
    status = rec.get('status', 'CRASH')
    checks = rec.get('query_checks') or []
    if status != 'PASS':
        reasons.append('status=%s' % status)
    if not checks:
        reasons.append('no query checks')
    elif not all(c.get('ok') for c in checks):
        reasons.append('query mismatch')
    for name, timer in (rec.get('timers') or {}).items():
        if isinstance(timer, dict) and timer.get('residual_fraction', 0) > CLOSURE_MAX:
            reasons.append('phase closure %s=%.4f' % (name, timer['residual_fraction']))
    total = service_total(rec)
    if total is None or total <= 0:
        reasons.append('no service total')
    return (not reasons), status, reasons


def distribution(records):
    """Valid-session distribution plus the full failure census."""
    census = {}
    valid = []
    for r in records:
        ok, status, reasons = validity(r)
        census[status] = census.get(status, 0) + 1
        if ok:
            valid.append(r)
    return {'census': census, 'valid': valid, 'n_total': len(records),
            'n_valid': len(valid), 'n_invalid': len(records) - len(valid)}


def paired_ratios(records, num='B3-Lazy', den='B3-Eager', resamples=10000, seed=20261110):
    """Median paired ratio over blocks, with a block bootstrap interval."""
    by_block = {}
    for r in records:
        c = r['config']
        key = (c.get('dataset'), c.get('route'), c.get('schedule'), c.get('block'))
        by_block.setdefault(key, {})[c.get('engine')] = service_total(r)
    ratios = []
    for key, per in sorted(by_block.items()):
        a, b = per.get(num), per.get(den)
        if a and b and b > 0:
            ratios.append(a / b)
    if not ratios:
        return None
    rng = random.Random(seed)
    boots = []
    n = len(ratios)
    for _ in range(resamples):
        sample = [ratios[rng.randrange(n)] for _ in range(n)]
        boots.append(statistics.median(sample))
    boots.sort()
    return {'n_pairs': n, 'median': statistics.median(ratios),
            'min': min(ratios), 'max': max(ratios),
            'ci95': [boots[int(0.025 * resamples)], boots[int(0.975 * resamples)]],
            'resamples': resamples, 'seed': seed}


def gate_selftest():
    """Four synthetic records: only the healthy one may enter the distribution."""
    base = {'timers': {'lifecycle': {'total_s': 1.0, 'residual_fraction': 0.001}},
            'query_checks': [{'state': 0, 'ok': True}], 'status': 'PASS'}
    bad_query = {'timers': {'lifecycle': {'total_s': 1.1, 'residual_fraction': 0.001}},
                 'query_checks': [{'state': 0, 'ok': False}], 'status': 'CORRECTNESS_FAIL'}
    bad_raw = {'timers': {'lifecycle': {'total_s': 1.2, 'residual_fraction': 0.001}},
               'query_checks': [{'state': 0, 'ok': True}], 'status': 'SOURCE_FAIL'}
    bad_close = {'timers': {'lifecycle': {'total_s': 1.3, 'residual_fraction': 0.05}},
                 'query_checks': [{'state': 0, 'ok': True}], 'status': 'PASS'}
    recs = [base, bad_query, bad_raw, bad_close]
    d = distribution(recs)
    ok = (d['n_valid'] == 1 and d['n_total'] == 4
          and d['census'].get('CORRECTNESS_FAIL') == 1
          and d['census'].get('SOURCE_FAIL') == 1)
    return {'ok': ok, 'entered_distribution': d['n_valid'],
            'rejected': d['n_invalid'], 'census': d['census'],
            'note': 'the third record has status PASS but fails the closure gate; '
                    'it must not enter the distribution'}
