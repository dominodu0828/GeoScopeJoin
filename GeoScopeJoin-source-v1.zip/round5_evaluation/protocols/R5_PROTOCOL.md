# Round 5 protocol (frozen before execution)

Frozen: 2026-11-10, before any Round 5 run. Any parameter change requires a new protocol
file and a new run directory; results from superseded protocols are not pooled.

Scope. This round answers three questions with measurements: (i) how query interval and
update overlap determine coalescing benefit; (ii) how source read, delta discovery and
output bound the end-to-end benefit; (iii) where plain full evaluation, a tile cache and
incremental maintenance are applicable under equal source semantics and a memory cap.
No new algorithm is claimed.

## Immutable history

`round2/`, `round3/`, `round4_replication/`, `paper_v1_20261106/`, `paper_v2_20261109/`
are read-only. Round 5 writes only under `round5_evaluation/`. Every run directory is
created exclusively (`exist_ok=False`); an existing directory is never reused.

## G0 validity gates (prerequisites, not polish)

G0.1 Real provenance. Every emitted row binds the SHA-256 of the source ZIP it was
decoded from (`rh`) and the SHA-256 of the point source file (`ph`). Point times that are
not documented use `snapshot:<sha256>`; no OSM cutoff time is invented. Derived hashes
(the 256x256 window NPY) are registered separately and never substituted for `rh`.
Gate: a source-only change (same values, different registered bytes) must change the
source suffix while leaving the semantic prefix identical; emitting the stale hash must
fail the gate.

G0.2 Dependency closure. The freeze covers every project module actually imported, the
runner entry points, the protocol, the parameter matrix, input metadata and the oracle
artifact, all keyed by path relative to the project root. Paths are resolved from the
manifest, never from the shell working directory. Unknown project modules abort the run.
Negative controls: one-byte edits to a direct source file, a transitive `round2`
dependency, the oracle, the protocol, the input manifest and the parameter matrix must
each be rejected.

G0.3 Failure gating. A session contributes to a performance distribution only if
`freeze_ok and parameters_match and every_query_matches and raw_validation_ok and
phase_contract_ok and budget_contract_ok`. Statuses: `PASS`, `CORRECTNESS_FAIL`,
`SOURCE_FAIL`, `FREEZE_FAIL`, `TIMING_INVALID`, `RESOURCE_LIMIT`, `CRASH`. Correctness
failure stops performance adjudication for that configuration; the minimal counterexample
is stored. Timer anomalies are never silently dropped.

G0.4 Independent numeric reference. Expected rows are rebuilt from the native array, the
native validity mask and the source transform; the candidate encoder, the affected set
and the reverse index are not called. The binary64 hex representation is checked from
the array's bit view, not by calling the same pack helper twice. Encodings tested: 0.5
(exact), 0.1 (denominator does not divide 2^32), the São Paulo rejected value, +0 and -0,
the NoData sentinel, NaN and Inf, and a non-default scale/offset product. Negative zero has
no distinct `units/2^32` representation and is an explicit rejection, not a silent sign
loss. Non-finite valid values are rejected.

## E1 two complete service routes (P0)

Datasets: `shenzhen_same_epoch_release_pair` (R2022A -> R2023A, E2020, three point
snapshots 2023/2024/2025, two events) and `sao_paulo_cross_epoch_published_grids`
(R2023A E2015->E2020->E2025->E2030, one fixed point snapshot, three events). They are
reported separately and never pooled into one "cross-release" sample.

Routes. `raw_service` starts from the archived ZIPs and JSON: source verification,
decoding, encoding, point preparation, delta discovery, engine build, updates, queries
and a hash sink are inside the lifecycle. `registered_service` imports verifiable
immutable snapshots first; `T_register` is measured once and kept; every online request
re-verifies snapshot identity, the query contract and the version chain.

Engines: `BFull-Fast` (re-evaluates every point per request from the current state,
direct grid lookup, no inverse index, no cross-query result cache), `B3-Eager`,
`B3-Lazy`. `B0`/native reference is the correctness judge and is never a performance
baseline.

Phases (mutually exclusive, one outer wall timer): source_verify, decode, encode,
point_prepare, diff, build, update, query, serialize, sink, close, plus explicitly
separated `freeze_check` and `correctness_check` experiment overhead. Lazy flush is a
sub-phase of query and is not added twice. Phase closure threshold: 1% of the outer
wall, absolute residual stored.

Matrix: 2 datasets x 2 routes x 2 schedules x 3 engines x 30 independent sessions = 720
base sessions. Three smoke blocks per dataset are excluded from analysis and are used
only to judge feasibility and budget, never to pick a favourable configuration.

Amortization extension: registered route, W2, engines B3-Eager and B3-Lazy, H in
{1,10,100}, 10 blocks per cell, with T_total(H) = T_register + sum_j T_online,j. Input
snapshot reuse is not mixed with result-cache reuse.

Adjudication: paired log-ratio and median paired ratio per data x route x schedule,
95% block-bootstrap interval (seed 20261110, 10,000 resamples). Practical threshold 5%:
an improvement is called stable only if the interval upper bound is below 0.95. Ratios
crossing 1, or tiny differences, are reported as no established advantage. 30 sessions
cannot support p99.

## E2 overlap x query gap (P0)

Synthetic-controlled, on a 256x256 grid, 3 proportional regions, 8192 points, one point
per distinct cell, 16 events, 256 affected points per event. Each event's affected set is
a shared core (h in {0,128,256}) plus an event-exclusive tail; tails are disjoint and the
candidate cell domain is large enough. Query gap L in {1,4,16} events per query. Five
preregistered layout seeds (1101..1105). Injected events are labelled
`synthetic-controlled`; values alternate between two exactly representable integers so
every designated point really changes at every event.

Fixed point set, fixed G and S, no insertions or deletions. Predictions:
C_E = n + sum_t |A_t|, C_L = n + sum_j |union_{t in B_j} A_t|, with zero residual. Points
created, deleted, source-only changes and full fallbacks are counted separately
(`initial_eval`, `new_eval`, `re_eval`, `deleted_skip`, `fallback_eval`).

Ablations: B3-Eager vs B3-Lazy (timing only), B3-Lazy-demand-init (necessary dependencies
only at build, semantics at first query; explained, not named as a new algorithm), and a
same-cell multi-point comparison at the two h endpoints with total point count and output
rules held fixed.

Timing endpoints, fixed in advance: (h,L) = (0,16), (256,1), (256,16); 30 paired sessions
each. Mechanism counts need 5 seeds, not 30 repeats. Stop rule: any healthy-vs-oracle
difference stops the performance analysis of that configuration.

## E5 source semantics and event closure (P1)

Known real move: OSM node 7639850987, version 2 -> 3, coordinates from the recorded
history; the window is the minimal native rectangle covering both cells plus two cells of
margin on the existing R7_C29 TIFF. If a position is not covered, the case is recorded as
insufficient rather than padded with zeros.

Cases: same raster with old/new point; and where both versions cover, the 2x2 request
(raster x point versions). Regions: one frozen region containing both positions plus one
explicitly marked `postselected` separator region to observe membership exit and entry.
Identical old/new values are kept as a successful case; the window is never reselected to
force a numerical change.

Strict event guard: `event_id, stream_id, sequence, base_version, target_version,
before_digest, after_digest, changes, payload_hash`. Accept only when base equals the
current version, the sequence is contiguous and the old digest matches. An identical
committed event is acknowledged idempotently; the same id with a different payload is
rejected; gaps, update-before-insert and stale update-after-delete are rejected with the
snapshot left unchanged. "Latest wins" is not used. No concurrency, serialization or
crash-recovery claim is derived from these tests.

NoData search: at most 2 product families, at most 3 native aligned pairs per family,
2 wall-clock hours and 1 GiB of new downloads; only with a new official source or a new
product mechanism. Absence is delivered as a search list and a negative result.

## E4 byte-budgeted cache (P1)

Accounting: immutable shared inputs are separate; engine state is measured over the whole
object graph with one visited set (no double counting of shared objects); process private
bytes and RSS peak are also recorded. B2-byte evicts by retained bytes, not by a guessed
tile count. A tile larger than the budget is computed and streamed without retention; the
budget is never silently enlarged. If a fixed index exceeds the budget, the engine reports
infeasible or switches to an explicit no-cache full evaluation. Budgets: calibration on a
separate fixture to obtain M0, then 0.5 M0, 1 M0, 2 M0. Every query passes the oracle.
Persistent-session traces cover 100 event blocks; report p50/p95 (not p99) with the
same-session correlation stated.

## E3 change discovery and scale (P1)

Two input contracts are separated: `S-full` discovers deltas from complete before/after
snapshots; `S-log` starts from a verified state baseline and a complete, validated delta
event chain, whose parsing, base/target checks, sequence checks, application and
verification are all inside the timer. If the log was built offline, `T_log_build` is
reported separately. One axis at a time: cells {256^2, 512^2, 1024^2} at N=10^4, G=3;
points {10^3, 10^4, 10^5} at 256^2, G=3; regions {3, 30, 300} at 256^2, N=10^4. Affected
fractions {0, 0.1%, 1%, 10%, 100%}; locality control at 1% and 10%. Large cases use the
native reference plus boundary and deterministic-sample naive scans; the shared-library
independence limit is stated and no O(P x C) double implementation is claimed for them.

## Resources and statistics

One performance session at a time; RSS cap 4 GiB per session; session timeout 120 s; at
most one controlled retry per configuration, whole pair rerun, never only the slow side.
Exceeding a limit is recorded as `RESOURCE_LIMIT`, never silently shrunk. Engine order
within a block is balanced by a fixed seed; OS, Python and library versions, thread count
and observed load are stored. A configuration's unit is a complete session/block, never a
query inside a shared process. Results with no advantage are delivered as such; runs are
not repeated until significance appears.
