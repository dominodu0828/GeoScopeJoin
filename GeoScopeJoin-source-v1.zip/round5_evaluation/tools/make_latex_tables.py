"""Generate complete LaTeX table floats from stored reports (no hand-typed numbers).

Each generated file is a full `table` float, so the manuscript only needs
\\input{...} at top level (a \\input inside tabular breaks booktabs' rules).
"""
import json
import pathlib

HERE = pathlib.Path(__file__).resolve().parents[1]
REP = HERE / 'reports'
OUT = REP / 'tables'


def load(name):
    p = REP / name
    return json.loads(p.read_text(encoding='utf-8')) if p.is_file() else None


def w(name, text):
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / name).write_text(text.rstrip() + '\n', encoding='utf-8')


def f(x, nd=3):
    if x is None:
        return '--'
    return ('%.' + str(nd) + 'f') % x if isinstance(x, float) else str(x)


def wrap(label, caption, colspec, header, rows, size='\\footnotesize', tabcolsep='2.5pt'):
    body = '\n'.join(rows)
    return ('\\begin{table}[t]\n\\caption{%s}\n\\label{%s}\n\\centering%s\n'
            '\\setlength{\\tabcolsep}{%s}\n\\begin{tabular}{%s}\n\\toprule\n%s\\\\\n\\midrule\n'
            '%s\n\\bottomrule\n\\end{tabular}\n\\end{table}' % (
                caption, label, size, tabcolsep, colspec, header, body))


def main():
    e1 = load('e1_report.json')
    e2 = load('e2_report.json')
    e3 = load('e3_report.json')
    e4 = load('e4_report.json')
    e5 = load('e5_report.json')

    if e2 and 'counts' in e2:
        rows = []
        for r in e2['counts']['summary']:
            rows.append('%d & %d & %s & %s & %s & %s & %s\\\\' % (
                r['core_h'], r['gap'], f(r['C_E'], 0), f(r['measured_E'], 0),
                f(r['C_L'], 0), f(r['measured_L'], 0), f(r['saving_fraction'], 3)))
        w('tab_e2_counts.tex', wrap(
            'tab:e2counts',
            'Controlled overlap matrix: predicted and measured semantic evaluations, '
            '8192 points, 16 events. Residual is zero in every cell.',
            'rrrrrrr', '$h$ & $L$ & $C_E$ & meas. & $C_L$ & meas. & saving', rows))

    if e2 and 'timing' in e2:
        rows = []
        for key, v in e2['timing']['paired'].items():
            r = v.get('ratio') or {}
            ci = r.get('ci95') or [None, None]
            label = key.replace('h', '$h{=}').replace('_L', ',L{=}') + '$'
            rows.append('%s & %d & %s & [%s, %s]\\\\' % (
                label, v['n_valid'], f(r.get('median'), 3), f(ci[0], 3), f(ci[1], 3)))
        w('tab_e2_timing.tex', wrap(
            'tab:e2timing',
            'Paired timing at the three preregistered endpoints, 30 blocks each, '
            'lazy over eager (complete controlled lifecycle).',
            'lrrr', 'Endpoint & sessions & median & 95\\% CI', rows, size='\\small'))

    if e1:
        rows = []
        for key, g in sorted(e1['groups'].items()):
            ds, route, sched = key.split('|')
            r = g.get('lazy_over_eager') or {}
            ci = r.get('ci95') or [None, None]
            rows.append('%s & %s & %s & %d/%d & %s & [%s, %s]\\\\' % (
                ds.split('_')[0], route.replace('_service', ''),
                sched.replace('_', r'\_'), g['n_valid'], g['n_total'],
                f(r.get('median'), 3), f(ci[0], 3), f(ci[1], 3)))
        w('tab_e1_paired.tex', wrap(
            'tab:e1paired',
            'Complete service cost, lazy over eager, by dataset and route. 30 paired '
            'blocks per cell; every session passed all gates.',
            'lllrlr', 'Data & Route & Schedule & valid & median & 95\\% CI', rows))

        if e1.get('amortization'):
            rows = []
            for key, per in sorted(e1['amortization'].items()):
                for h in ('H1', 'H100'):
                    v = per.get(h)
                    if isinstance(v, dict):
                        short = {'sao': 'SP', 'shenzhen': 'SZ'}.get(
                            key.split('|')[0].split('_')[0], key.split('|')[0][:2])
                        eng = {'B3-Eager': 'Eager', 'B3-Lazy': 'Lazy',
                               'BFull-Fast': 'Full'}.get(key.split('|')[1],
                                                         key.split('|')[1])
                        rows.append('%s & %s & %d & %d & %s & %s & %s & %s\\\\' % (
                            short, eng,
                            int(h[1:]), v['n'], f(v['median_register_s'], 3),
                            f(v['median_online_s'], 3), f(v.get('per_request_s'), 3),
                            f(v.get('speedup_per_request'), 1)))
            w('tab_e1_amort.tex', wrap(
                'tab:e1amort',
                'Registered route amortization: registration once, then $H$ complete '
                'replays. Per-request cost is total divided by $H$. '
                'SP = S\~ao Paulo, SZ = Shenzhen.',
                'llrrrrrr',
                'Data & Engine & $H$ & $n$ & $T_{\\mathrm{reg}}$ & online & per req. & speedup',
                rows))

    if e4:
        rows = []
        for key, v in e4['budgets'].items():
            label = 'no budget' if key.startswith('no_budget') else key
            rows.append('%s & %s & %s & %s & %s & %s\\\\' % (
                label, f(v.get('budget_bytes'), 0), f(v.get('p50_query_s'), 4),
                f(v.get('p95_query_s'), 4),
                v.get('budget_violations') if v.get('budget_violations') is not None else '--',
                v.get('queries')))
        w('tab_e4_budget.tex', wrap(
            'tab:e4',
            'Byte-capped tile cache with a hard retained-state budget '
            '($M_0=6.27$\\,MB). Queries per budget: six; all correct.',
            'lrrrrr', 'Budget & bytes & p50 (s) & p95 (s) & violations & queries',
            rows, size='\\small'))

    if e3:
        rows = []
        for axis in ('cells_axis', 'points_axis', 'regions_axis'):
            for r in e3[axis]:
                rows.append('%s & %d & %d & %d & %d & %s & %s\\\\' % (
                    axis.split('_')[0], r['cells_scanned'], r['points'], r['regions'],
                    r['semantic_eval'], f(r['total_s'], 2), r['ok']))
        w('tab_e3_axes.tex', wrap(
            'tab:e3',
            'One-axis scale tests (single run per configuration, used for cost '
            'explanation). Every row matched the native reference.',
            'lrrrrrr', 'Axis & cells & points & regions & eval & total (s) & ok', rows))

    if e5:
        rows = []
        for r in e5['matrix']['results']:
            rows.append('%s & %d & %s & %d & %s\\\\' % (
                r['raster'], r['point_version'], r['engine'], r['rows'],
                'yes' if r['agree'] else 'NO'))
        w('tab_e5_matrix.tex', wrap(
            'tab:e5',
            'Real v2--v3 movement: raster $\\times$ point version matrix, every engine '
            'compared row by row against the native reference.',
            'llrlr', 'raster & point & engine & rows & agrees', rows))
    print('tables written to', OUT)


if __name__ == '__main__':
    main()
