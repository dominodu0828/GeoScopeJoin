"""Rebuild the amortization table from stored session records (analysis only).

The E1 runner filtered H>1 out of `data` for the paired base analysis, which also
starved the amortization post-processing. Nothing needs re-measuring: every session
record stores T_register and the online sum, so the table is recomputed from artifacts.
"""
import json
import pathlib
import statistics
import sys

HERE = pathlib.Path(__file__).resolve().parents[1]
PROJ = HERE.parent
sys.path[:0] = [str(HERE / 'code')]

import r5_common as C


def main():
    rep = C.read_json(HERE / 'reports' / 'e1_report.json')
    run_dir = PROJ / rep['run_dir']
    recs = []
    for f in sorted((run_dir / 'sessions').glob('*.json')):
        d = C.read_json(f)
        c = d.get('config') or {}
        if c.get('route') != 'registered_service' or c.get('schedule') != 'W2_final_only':
            continue
        if c.get('H', 1) not in (1, 10, 100):
            continue
        # blocks 0-2 are the preregistered smoke blocks, excluded from analysis
        if d.get('status') != 'PASS' or c.get('block', 99) < 3:
            continue
        t = d.get('timers') or {}
        reg = (t.get('register') or {}).get('total_s')
        on = t.get('online_total_s')
        if reg is None or on is None:
            continue
        recs.append({'dataset': c['dataset'], 'engine': c['engine'], 'H': c['H'],
                     'block': c['block'], 'register_s': reg, 'online_s': on,
                     'smoke': d.get('smoke')})
    # one record per (dataset, engine, block, H): retries must not double count
    seen, uniq = set(), []
    for r in recs:
        key = (r['dataset'], r['engine'], r['block'], r['H'])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(r)
    recs = uniq

    out = {}
    for r in recs:
        out.setdefault('%s|%s' % (r['dataset'], r['engine']), {}) \
           .setdefault('H%d' % r['H'], []).append(r)
    table = {}
    for key, per in sorted(out.items()):
        table[key] = {}
        for h, rows in per.items():
            table[key][h] = {
                'n': len(rows),
                'median_register_s': statistics.median(x['register_s'] for x in rows),
                'median_online_s': statistics.median(x['online_s'] for x in rows),
                'median_register_share': statistics.median(
                    x['register_s'] / (x['register_s'] + x['online_s']) for x in rows)}
        base = table[key].get('H1')
        if base:
            base_per_req = base['median_register_s'] + base['median_online_s']
            base['per_request_s'] = base_per_req
            for h in ('H10', 'H100'):
                if h in table[key]:
                    total_h = (table[key][h]['median_register_s']
                               + table[key][h]['median_online_s'])
                    per_req = total_h / int(h[1:])
                    table[key][h]['per_request_s'] = per_req
                    # amortization: per-request service cost relative to one request
                    table[key][h]['speedup_per_request'] = base_per_req / per_req
    rep['amortization'] = table
    rep['amortization_note'] = ('recomputed from stored session records by '
                                'tools/recompute_amort.py; no re-measurement')
    C.write_json(HERE / 'reports' / 'e1_report.json', rep)
    for key, per in sorted(table.items()):
        print(key)
        for h in ('H1', 'H10', 'H100'):
            v = per.get(h)
            if not v:
                continue
            extra = ''
            if 'speedup_per_request' in v:
                extra = 'per_request=%.3fs speedup=%.1fx' % (
                    v.get('per_request_s', 0.0), v.get('speedup_per_request', 0.0))
            print('  %-4s n=%d register=%.3f online=%.3f share=%.3f %s' % (
                h, v['n'], v['median_register_s'], v['median_online_s'],
                v['median_register_share'], extra))
    return 0


if __name__ == '__main__':
    sys.exit(main())
