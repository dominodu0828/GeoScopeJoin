"""Verify portable source identity and run four correctness smoke sessions.

Run after run_g0.py. Timings here are not benchmark results.
"""
import json, pathlib, subprocess, sys
root = pathlib.Path(__file__).resolve().parent
r5 = root / 'round5_evaluation'
out = root / 'publication_validation'
out.mkdir(exist_ok=True)
checks = {}
for name in ('shenzhen_same_epoch_release_pair', 'sao_paulo_cross_epoch_published_grids'):
    old = json.loads((root / 'historical_results/manifests' / ('dataset_' + name + '.json')).read_text())
    new = json.loads((r5 / 'manifests' / ('dataset_' + name + '.json')).read_text())
    assert old == new, 'dataset manifest changed: ' + name
    old_o = json.loads((root / 'historical_results/manifests' / ('oracle_' + name + '.json')).read_text())
    new_o = json.loads((r5 / 'manifests' / ('oracle_' + name + '.json')).read_text())
    assert old_o == new_o, 'oracle changed: ' + name
    for route in ('raw_service', 'registered_service'):
        key = name + '__' + route
        work = out / key
        work.mkdir(exist_ok=True)
        cfg = {'dataset': name, 'route': route, 'schedule': 'W3_each_state',
               'engine': 'B3-Lazy', 'block': 3, 'H': 1, 'run_dir': str(work)}
        conf, result = work / 'config.json', work / 'result.json'
        conf.write_text(json.dumps(cfg), encoding='utf-8')
        subprocess.run([sys.executable, '-I', str(r5 / 'code/session_runner.py'),
                        '--config', str(conf), '--out', str(result)], check=True, cwd=root)
        doc = json.loads(result.read_text())
        assert doc['status'] == 'PASS'
        checks[key] = {'status': doc['status'], 'checks_ok': doc['checks_ok'],
                       'checks_total': doc['checks_total']}
g0 = json.loads((r5 / 'reports/g0_report.json').read_text())
e5 = json.loads((r5 / 'reports/e5_report.json').read_text())
old_e1 = json.loads((root / 'historical_results/reports/e1_report.json').read_text())
new_e1 = json.loads((r5 / 'reports/e1_report.json').read_text())
assert old_e1['amortization'] == new_e1['amortization']
assert g0['all_gates_pass'] and e5['matrix']['all_agree'] and e5['event_guard']['ok']
summary = {'python': sys.version, 'dataset_manifests_match_historical': True,
           'oracles_match_historical': True, 'g0_all_gates_pass': True,
           'g0_closure_files': g0['freeze']['files'], 'e5_matrix_rows': len(e5['matrix']['results']),
           'e5_matrix_all_agree': True, 'e5_event_guard': True,
           'amortization_exactly_matches_historical': True, 'service_smoke': checks,
           'scope': 'Packaging/path portability validation; full performance matrix not remeasured.'}
(out / 'SUMMARY.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
