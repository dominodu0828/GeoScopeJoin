import hashlib, json, pathlib, sys
root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root / 'ARTIFACT_INVENTORY.json').read_text(encoding='utf-8'))
bad = []
for name, record in manifest['files'].items():
    p = root / name
    if not p.is_file():
        bad.append('missing: ' + name)
        continue
    with p.open('rb') as f:
        actual = hashlib.file_digest(f, 'sha256').hexdigest()
    if actual != record['sha256']:
        bad.append('mismatch: ' + name)
print(json.dumps({'checked': len(manifest['files']), 'problems': bad}, indent=2))
sys.exit(bool(bad))
